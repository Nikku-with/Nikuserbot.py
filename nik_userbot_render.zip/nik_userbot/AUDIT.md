# nik userbot — verification report

## Result

**572 tests passed; 85% statement coverage.** Executed with Python 3.13.14 in this sandbox. Full output: `docs/test-results.txt`.

There are **168 registered command names across 18 categories**. Four names are documented aliases (`cp`, `normal`, `delmine`, `invitebots`); `menu2` is a navigation shortcut. This is not a claim of 168 independent capabilities. Every name maps to an async handler; the menu/help/reference are generated from the registry.

## Ten review/test areas

| Area | Evidence | Boundary |
|---|---|---|
| 1. Registration and parsing | Every registered handler is async and has usage/category/help; parser and excluded-scope checks | Registration alone does not prove a live API flow |
| 2. JSON storage | Restart reload, 100 concurrent mutations, defensive copies, restrictive mode, corrupt/disk-failure tests | Single instance only; no distributed lock |
| 3. Authorization/configuration | Owner, sudo, owner-only, token expiry/chat binding, missing/bad credentials, safe expression rejection | Real session login not attempted |
| 4. Text utilities | Every transform runs; arithmetic whitelist, complexity and unsafe-expression tests | Unicode reversing is codepoint-based, not grapheme-aware |
| 5. Cleaning/messaging | Confirmed and bounded mock deletes, own-message filtering, invalid counts, cancellations, forwarding/reaction API construction | Real group history/delete limits not exercised |
| 6. Moderation/chats | Default-rights serialization, exact muteall restoration, preservation of title rights, promotion confirmation, named bot flows | Telegram permissions and group types may reject requests |
| 7. Automation | Real persisted config with mocked delivery; opt-in/out, no-consent rejection, reply cooldowns, schedules, forwarding and reminder flow | Crash-boundary delivery is not exactly-once |
| 8. Personal/profile | Notes/reminders round trips, AFK, profile snapshot preservation, restore, photo upload tracking | Live avatar and Telegram profile changes not performed |
| 9. Media | Real FFmpeg sine-wave → MP3; FFprobe verification; rejects renamed WAV; real local conversions/images; download pipeline mocked | YouTube/SoundCloud network access and Render IP not tested |
| 10. Menus/animations | Help for every command; every name appears in paginated messages; 21–24 frame counts and mocked edits | Telegram edit rate limits remain external |

The final checks additionally included compileall, Ruff undefined/unused-name checks, dependency consistency (`pip check`), start-script syntax and package/config integrity checks. Ten areas are substantive distinct checks, not a promise that running a compiler ten times proves correctness.

## Issues found and corrected while testing

- A raw Telegram banned-right field uses `embed_links`, not the high-level helper name `embed_link_previews`. The test serializes rights to catch unsupported attribute mistakes.
- Large category-based menus exceeded the message budget and became file attachments. Menus now use 14 entries/page; all 12 pages are tested as messages.
- First-use cooldowns incorrectly assumed machine monotonic uptime exceeded an hour. Missing keys now allow the first use immediately; a fresh-machine regression test covers it.
- Individual mute/unmute now preserve unrelated user restrictions, rather than resetting every permission through broad defaults.
- Audio conversion uses a separate output directory to avoid overwriting a same-named input file.
- Subprocesses run in an isolated process group so cancellation kills the conversion/downloader process tree.
- Sudo replies are new messages, never edits of another person's command.
- Long result payloads become text attachments instead of slicing HTML tags.

## Honest limitations

No Telegram credentials were used. No Telegram live-account tests, actual Render deployment or Docker build ran here. Tests use mocked Telegram objects, so passing them does not prove server-side permissions, all account states, rate limits, source hosting availability or every API edge case. Network failures return errors rather than a false success message.

572 includes parameterized registry/help tests and is **not** 572 end-to-end integration tests. Approximately 15% of executable statements were not covered by the suite. Destructive commands must be checked in a disposable owned supergroup first; use `docs/LIVE_CHECKLIST.md`.

The old claim “all features working / no error” is not repeated here. This package has implemented handlers, reproducible local tests and a documented deployment configuration, not a zero-bug guarantee.
