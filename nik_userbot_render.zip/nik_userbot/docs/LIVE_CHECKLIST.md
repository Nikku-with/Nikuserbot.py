# First-deployment checklist — not yet executed

Use Saved Messages plus a disposable supergroup you own. Wait at least one second between commands. Do not start with real chats or large deletions.

- [ ] Log shows authorized owner and registration count; no interactive login prompt.
- [ ] `.ping`, `.alive`, `.menu`, `.menu2`, `.menu 12`, `.help purge`, `.commands` respond.
- [ ] Owner link points to your account. Another non-sudo account cannot run `.ping` through it.
- [ ] Add a trusted test user with `.sudo`; they can use `.ping` but cannot use `.sudo`, `.purge` or `.name`. Revoke access.
- [ ] `.notesadd test | persistent`, restart the worker, then `.note test` returns the value.
- [ ] With a consenting second account, send `.optin` privately. Confirm `.bclist`. Send `.optout`; confirm destination is removed.
- [ ] Test `.areply`, `.stopareply`, `.filter`, `.unfilter` in the disposable group. Verify no more than one configured response per minute.
- [ ] Test `.react 👍`, `.unreact` on a disposable message.
- [ ] Reply to owned media with `.dl`, `.mediainfo`, `.tomp3`. Confirm the output is playable audio, not a video.
- [ ] `.music` with your own permitted URL succeeds or produces an honest source/tool error. Public-host restrictions are not interpreted as a code pass.
- [ ] `.love` edits one message across 23 steps, then finishes. `.animstop` stops another animation.
- [ ] `.copy` then `.nrml` restore name/bio and reveal the retained original photo. Do not delete your original photo manually during the test.
- [ ] `.addbots @your_test_bot`, `.bots`, `.rmbots @your_test_bot` work only with adequate permissions.
- [ ] Test mute/unmute and pin/unpin on consenting disposable-group accounts/messages. Test title/promote only if you can grant the required rights.
- [ ] `.muteall`, inspect defaults, `.unmuteall`, verify the exact previous defaults return.
- [ ] `.purgeme 3` does nothing until its confirmation token is used in the same chat. Confirm only your pre-command messages are selected.
- [ ] `.purge 3` with permissions deletes only the bounded test selection after confirmation. Do not test 9999 first.
- [ ] `.remind 30s test` delivers privately; restart before due time and verify persistence.
- [ ] `.backup` reaches Saved Messages, not the group.
- [ ] `.stopall` stops running jobs and clears automatic messaging configuration as documented.
- [ ] Logs show no repeated FloodWait errors. If rate-limited, stop and wait; do not increase concurrency.
