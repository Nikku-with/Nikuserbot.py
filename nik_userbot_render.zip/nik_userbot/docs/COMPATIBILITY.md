# Legacy scope and deliberate differences

This is a new Telethon-only modular implementation. Legacy Python sources were read for command inventory; no legacy module is imported at runtime. See `legacy_inventory.json` for the 31 files scanned. That inventory extracts literal `.command(...)` registrations; it does not enumerate every regex, dynamic registration or feature in those files. Reading/inventorying those files is not an assertion that every legacy flow was validated.

## Retained or reimplemented

Messaging, bounded purge/purgeme/delmine/deall, single forwarding, saved messages, reactions, filters, individual moderation, limited/full promotion with appropriate checks, title/pin/unpin, group defaults, bot invitation/removal, joining, public-profile copy and restore, sudo, notes, persisted reminders, autoread, permitted replies/forwarding, opt-in broadcasts, MP3 music/conversion, replied-media download, image tools, text tools, owner-linked menus and animations. The definitive list is `COMMANDS.md`.

## Changed intentionally

- `.reply` is a single reply, not a target-following raid.
- `.autobc` requires consent and a minimum six-hour schedule, with at most 25 destinations per run.
- `.autofw` is limited to one message/minute, no private-source bulk forwarding, no chains or historical replay.
- `.muteall` updates reversible group defaults; it does not mutate every member's individual permissions.
- `.deall` is a confirmed cleanup of your messages in the current chat, capped at 9999; never every dialog.
- `.dl` downloads replied accessible Telegram media; it is not an unrestricted URL fetcher.
- `.cp` / `.copy` back up your existing profile first. `.nrml` restores names/bio and removes bot-added photos while retaining the previous photo if it was not deleted elsewhere. Usernames, premium attributes, emoji status and account identity are not copied.
- `.addbots` / `.invitebots` / `.rmbots` require explicit bot usernames, max three. No scraping or mass invitation/removal.
- The bot uses your session's owner ID, not an old hardcoded ID. Old Pyrogram session strings are incompatible; generate a Telethon session.

## Not included, and not shown as fake menu entries

- Targeted gaali/abuse raid engines (`rr`, `srr`, attack-style `reply`, `abuse`, `bomb`, `slap`, `spray`, `vloop`, `vhit`, `swipe`), flood loops and abusive text banks.
- Unsolicited mass tagging, mass banning/kicking and global retaliation lists.
- Voice-chat streaming/player stacks and legacy agentic integrations.
- `.ai`, `.weather`, `.ip`, `.short`, and arbitrary-URL download services. No unavailable third-party feature is advertised as working, and no external API key is required.

Use `.stopall`, not legacy raid stop aliases. Use `.help <command>` for the new exact syntax; legacy subcommand arguments are not automatically translated.
