import inspect
import pytest
from nik.registry import COMMANDS, parse


@pytest.mark.parametrize("name", list(COMMANDS))
def test_real_registered_handler(name):
    spec = COMMANDS[name]
    assert inspect.iscoroutinefunction(spec.handler)
    assert spec.usage.startswith("." + name)
    assert spec.description and spec.category
    assert not any(
        t in spec.description.lower()
        for t in ["coming soon", "not implemented", "placeholder"]
    )


def test_count_and_scope():
    assert len(COMMANDS) >= 150
    assert not {"rr", "abuse", "spam", "banall", "kickall"} & COMMANDS.keys()


@pytest.mark.parametrize(
    "text,want",
    [
        (".ping", ("ping", "")),
        (".MUSIC hello world", ("music", "hello world")),
        ("hi", None),
        ("..ping", None),
        (".", None),
        (".  ", None),
    ],
)
def test_parser(text, want):
    assert parse(text) == want
