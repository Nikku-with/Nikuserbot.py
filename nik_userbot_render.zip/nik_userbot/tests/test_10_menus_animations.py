import asyncio
import pytest
from nik.registry import COMMANDS
from nik.plugins.animations import ANIMATIONS


async def test_menu_pages_cover_every_category(ctx):
    from nik.plugins.system import menu_entries

    pages = len(menu_entries())
    for page in range(1, pages + 1):
        ctx.args = str(page)
        await COMMANDS["menu"].handler(ctx)
    outputs = "\n".join(call.args[1] for call in ctx.client.send_message.call_args_list)
    for name in COMMANDS:
        assert "." + name + "</code>" in outputs
    assert "beat hinata" not in outputs.lower() and "beast" not in outputs.lower()


@pytest.mark.parametrize("name", list(COMMANDS))
async def test_every_command_has_help(ctx, name):
    ctx.args = name
    await COMMANDS["help"].handler(ctx)
    assert "Access:" in ctx.client.send_message.call_args.args[1]


@pytest.mark.parametrize("name", list(ANIMATIONS))
async def test_animation_frames(ctx, name, monkeypatch):
    async def immediate(*args):
        pass

    monkeypatch.setattr("nik.plugins.animations.asyncio.sleep", immediate)
    await COMMANDS[name].handler(ctx)
    tasks = list(ctx.app.jobs.values())
    await asyncio.gather(*tasks)
    msg = ctx.client.send_message.return_value
    assert msg.edit.await_count == len(ANIMATIONS[name]) - 1
    assert len(ANIMATIONS[name]) >= 21


@pytest.mark.parametrize(
    "name,args",
    [
        ("menu2", ""),
        ("commands", ""),
        ("alive", ""),
        ("uptime", ""),
        ("id", ""),
        ("chatid", ""),
        ("info", ""),
        ("sudo", "@guest"),
        ("delsudo", "@guest"),
        ("sudolist", ""),
        ("cancel", ""),
        ("jobs", ""),
        ("backup", ""),
        ("settings", ""),
        ("animstop", ""),
    ],
)
async def test_system_handlers(ctx, name, args):
    ctx.args = args
    await COMMANDS[name].handler(ctx)
    assert ctx.client.send_message.await_count or ctx.client.send_file.await_count
