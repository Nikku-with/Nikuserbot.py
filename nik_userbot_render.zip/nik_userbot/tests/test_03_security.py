import time
from unittest.mock import AsyncMock
import pytest
from nik.app import dispatch
from nik.core import UserError
from nik.registry import COMMANDS


async def test_unknown_sender(ctx):
    ctx.event.sender_id = 55
    await dispatch(ctx.app, ctx.event)
    ctx.client.get_me.assert_not_awaited()


async def test_owner_ping(ctx):
    await dispatch(ctx.app, ctx.event)
    ctx.client.get_me.assert_awaited_once()
    assert "tg://user?id=1" in ctx.client.send_message.call_args.args[1]


async def test_sudo_can_ping(ctx):
    await ctx.store.set("sudo", [2])
    ctx.event.sender_id = 2
    await dispatch(ctx.app, ctx.event)
    ctx.client.get_me.assert_awaited_once()


async def test_sudo_cannot_owner_command(ctx):
    await ctx.store.set("sudo", [2])
    ctx.event.sender_id = 2
    ctx.event.raw_text = ".sudo @someone"
    await dispatch(ctx.app, ctx.event)
    assert ctx.store.get("sudo") == [2]
    assert "Owner-only" in ctx.client.send_message.call_args.args[1]


async def test_confirm_binding(ctx):
    fn = AsyncMock()
    await ctx.confirm("Delete?", fn)
    token = next(iter(ctx.app.pending))
    ctx.args = token
    ctx.chat = -99
    with pytest.raises(UserError):
        await COMMANDS["confirm"].handler(ctx)
    assert token in ctx.app.pending
    ctx.chat = -100123
    await COMMANDS["confirm"].handler(ctx)
    fn.assert_awaited_once()
    with pytest.raises(UserError):
        await COMMANDS["confirm"].handler(ctx)


async def test_expired_confirm(ctx):
    fn = AsyncMock()
    ctx.app.pending["expired"] = (time.monotonic() - 1, ctx.chat, 1, fn)
    ctx.args = "expired"
    with pytest.raises(UserError):
        await COMMANDS["confirm"].handler(ctx)
    fn.assert_not_awaited()


async def test_owner_only_dangerous_commands():
    for name in [
        "sudo",
        "delsudo",
        "purge",
        "purgeme",
        "deall",
        "copy",
        "name",
        "bio",
        "pfp",
        "bc",
        "autobc",
        "autofw",
        "invite",
        "rmbots",
        "ban",
        "fullpromote",
        "backup",
        "password",
    ]:
        assert COMMANDS[name].owner


async def test_first_cooldown_allowed_even_on_fresh_machine(ctx, monkeypatch):
    monkeypatch.setattr("nik.core.time.monotonic", lambda: 0.1)
    assert ctx.app.allowed("first", 3600)
    assert not ctx.app.allowed("first", 3600)


async def test_startup_missing_credentials(monkeypatch):
    from nik.app import main

    for name in ["API_ID", "API_HASH", "SESSION_STRING"]:
        monkeypatch.delenv(name, raising=False)
    with pytest.raises(SystemExit, match="Set Render environment variables"):
        await main()


async def test_startup_bad_session(monkeypatch):
    from nik.app import main

    monkeypatch.setenv("API_ID", "123")
    monkeypatch.setenv("API_HASH", "a" * 32)
    monkeypatch.setenv("SESSION_STRING", "not-a-telethon-session")
    with pytest.raises(SystemExit, match="TELETHON"):
        await main()


async def test_escaped_errors_and_invalid_command(ctx):
    ctx.event.raw_text = '.calc __import__("os")'
    await dispatch(ctx.app, ctx.event)
    assert "⚠️" in ctx.client.send_message.call_args.args[1]


async def test_oversize_response_is_file(ctx):
    await ctx.say("<b>" + "x" * 8000 + "</b>")
    ctx.client.send_file.assert_awaited_once()
    assert ctx.client.send_file.call_args.args[1].getvalue() == b"x" * 8000
