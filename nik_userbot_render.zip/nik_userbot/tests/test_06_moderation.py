import pytest
from telethon import types
from nik.registry import COMMANDS
from nik.plugins.moderation import LOCKS


@pytest.mark.parametrize(
    "name",
    [
        "kick",
        "ban",
        "unban",
        "mute",
        "unmute",
        "delkick",
        "delban",
        "delmute",
        "staff",
        "promote",
        "demote",
        "pin",
        "unpin",
    ],
)
async def test_mod_flows(ctx, name):
    ctx.args = "@guest"
    await COMMANDS[name].handler(ctx)
    assert ctx.client.send_message.await_count >= 1


@pytest.mark.parametrize("permission", list(LOCKS))
async def test_lock_roundtrip(ctx, permission):
    ctx.args = permission
    await COMMANDS["lock"].handler(ctx)
    rights = ctx.client.requests[-1].banned_rights
    assert getattr(rights, LOCKS[permission]) is True
    # Serialize to catch invalid TL fields rather than arbitrary Python attributes.
    decoded = types.ChatBannedRights.from_reader(
        __import__("telethon").extensions.BinaryReader(bytes(rights)[4:])
    )
    assert getattr(decoded, LOCKS[permission]) is True
    await COMMANDS["unlock"].handler(ctx)
    assert getattr(ctx.client.requests[-1].banned_rights, LOCKS[permission]) is False


async def test_muteall_restores_defaults(ctx):
    await COMMANDS["muteall"].handler(ctx)
    assert ctx.client.requests[-1].banned_rights.send_messages is True
    await COMMANDS["unmuteall"].handler(ctx)
    rights = ctx.client.requests[-1].banned_rights
    assert rights.send_polls is True and not rights.send_messages
    assert not ctx.store.get("chat_backup")


async def test_fullpromote_requires_confirmation(ctx):
    await COMMANDS["fullpromote"].handler(ctx)
    ctx.client.edit_admin.assert_not_awaited()
    ctx.args = next(iter(ctx.app.pending))
    await COMMANDS["confirm"].handler(ctx)
    assert ctx.client.edit_admin.call_args.kwargs["add_admins"] is True


async def test_title_preserves_rights(ctx):
    ctx.event.is_reply = True
    ctx.args = "Moderator"
    await COMMANDS["title"].handler(ctx)
    req = ctx.client.requests[-1]
    assert req.rank == "Moderator" and req.admin_rights.delete_messages


@pytest.mark.parametrize(
    "name,args",
    [
        ("group", "title New name"),
        ("group", "desc New description"),
        ("locks", ""),
        ("join", "@group"),
        ("join", "https://t.me/+testtoken"),
        ("invite", "@guest"),
        ("bots", ""),
        ("chatinfo", ""),
    ],
)
async def test_chat_flows(ctx, name, args):
    ctx.args = args
    await COMMANDS[name].handler(ctx)
    ctx.client.send_message.assert_awaited()


@pytest.mark.parametrize("name", ["addbots", "invitebots", "rmbots"])
async def test_named_bot_flows(ctx, name, monkeypatch):
    async def immediate(*a):
        pass

    monkeypatch.setattr("nik.plugins.moderation.asyncio.sleep", immediate)
    ctx.client.user.bot = True
    ctx.args = "@guest"
    await COMMANDS[name].handler(ctx)
    assert "failed" not in ctx.client.send_message.call_args.args[1]


async def test_leave_confirmation(ctx):
    await COMMANDS["leave"].handler(ctx)
    ctx.client.delete_dialog.assert_not_awaited()
    ctx.args = next(iter(ctx.app.pending))
    await COMMANDS["confirm"].handler(ctx)
    ctx.client.delete_dialog.assert_awaited_once()
