import pytest
from nik.plugins.automation import incoming
from nik.registry import COMMANDS
from nik.core import UserError


async def test_recipient_opt_in_out(ctx):
    ctx.event.sender_id = 2
    ctx.event.chat_id = 2
    ctx.event.is_private = True
    ctx.event.raw_text = ".optin"
    await incoming(ctx.app, ctx.event)
    assert ctx.store.get("broadcast") == [2]
    await ctx.store.set("areply", {"2": "hello"})
    await ctx.store.set("autofw", {"-100123": 2})
    ctx.event.raw_text = ".optout"
    await incoming(ctx.app, ctx.event)
    assert (
        not ctx.store.get("broadcast")
        and not ctx.store.get("areply")
        and not ctx.store.get("autofw")
    )


async def test_no_private_areply_without_consent(ctx):
    ctx.event.is_private = True
    ctx.chat = 2
    ctx.args = "Hello"
    with pytest.raises(UserError):
        await COMMANDS["areply"].handler(ctx)


async def test_reply_rate_limit(ctx):
    await ctx.store.set("areply", {str(ctx.event.chat_id): "Hello"})
    ctx.event.sender_id = 2
    ctx.event.raw_text = "hello"
    await incoming(ctx.app, ctx.event)
    await incoming(ctx.app, ctx.event)
    assert ctx.client.send_message.await_count == 1


async def test_commands_not_auto_replied(ctx):
    await ctx.store.set("areply", {str(ctx.event.chat_id): "Hello"})
    ctx.event.sender_id = 2
    ctx.event.raw_text = ".ping"
    await incoming(ctx.app, ctx.event)
    ctx.client.send_message.assert_not_awaited()


async def test_filter_exact_match(ctx):
    ctx.args = "Hello | Welcome"
    await COMMANDS["filter"].handler(ctx)
    assert ctx.store.get("filters")[str(ctx.chat)] == {"hello": "Welcome"}
    ctx.args = "hello"
    await COMMANDS["unfilter"].handler(ctx)
    assert not ctx.store.get("filters")[str(ctx.chat)]


@pytest.mark.parametrize("args", ["on 0 | hi", "on 1 | hi", "on 5 | hi", "on nan | hi"])
async def test_broadcast_minimum_interval(ctx, args):
    ctx.args = args
    with pytest.raises(UserError):
        await COMMANDS["autobc"].handler(ctx)


async def test_valid_schedule_persists(ctx):
    ctx.args = "on 6 | hi"
    await COMMANDS["autobc"].handler(ctx)
    assert ctx.store.get("autobc")["interval"] == 21600


async def test_forwarding_cannot_target_unsubscribed(ctx):
    ctx.args = "add @guest"
    with pytest.raises(UserError):
        await COMMANDS["autofw"].handler(ctx)


@pytest.mark.parametrize(
    "name,args",
    [
        ("optin", ""),
        ("optout", ""),
        ("filters", ""),
        ("areply", "Hello"),
        ("stopareply", ""),
        ("autoread", "on"),
        ("autoread", "off"),
        ("bcadd", ""),
        ("bcdel", ""),
        ("bclist", ""),
        ("autobc", "off"),
        ("autobc", "status"),
        ("autofw", "off"),
        ("autofw", "list"),
    ],
)
async def test_automation_handlers(ctx, name, args):
    ctx.args = args
    await COMMANDS[name].handler(ctx)
    ctx.client.send_message.assert_awaited()


async def test_autofw_sends_only_opted_in(ctx):
    await ctx.store.set("broadcast", [2])
    ctx.args = "add @guest"
    await COMMANDS["autofw"].handler(ctx)
    assert ctx.store.get("autofw")[str(ctx.chat)] == 2
    ctx.event.sender_id = 2
    ctx.event.raw_text = "news"
    await incoming(ctx.app, ctx.event)
    ctx.client.forward_messages.assert_awaited_once()
    await ctx.store.set("broadcast", [])
    ctx.app.cooldowns.clear()
    await incoming(ctx.app, ctx.event)
    assert ctx.client.forward_messages.await_count == 1


async def test_bc_confirmation_and_delivery(ctx, monkeypatch):
    import asyncio

    async def immediate(*a):
        pass

    monkeypatch.setattr("nik.plugins.automation.asyncio.sleep", immediate)
    await ctx.store.set("broadcast", [2])
    ctx.args = "hello"
    await COMMANDS["bc"].handler(ctx)
    ctx.args = next(iter(ctx.app.pending))
    await COMMANDS["confirm"].handler(ctx)
    await asyncio.gather(*list(ctx.app.jobs.values()))
    assert any(call.args[0] == 2 for call in ctx.client.send_message.call_args_list)


async def test_reminder_scheduler_sends_and_removes(ctx, monkeypatch):
    import asyncio
    from nik.plugins.automation import scheduler

    async def tick(seconds):
        if seconds == 15:
            raise asyncio.CancelledError()

    monkeypatch.setattr("nik.plugins.automation.asyncio.sleep", tick)
    await ctx.store.set("reminders", [{"id": "a", "at": 1, "text": "test reminder"}])
    with pytest.raises(asyncio.CancelledError):
        await scheduler(ctx.app)
    assert not ctx.store.get("reminders")
    assert "test reminder" in ctx.client.send_message.call_args.args[1]
