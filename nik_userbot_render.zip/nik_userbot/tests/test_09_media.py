import pytest
from nik.plugins.media import media_target, process, probe, send_mp3
from nik.core import UserError


@pytest.mark.parametrize(
    "url",
    [
        "http://youtube.com/watch?v=x",
        "https://127.0.0.1/file",
        "file:///etc/passwd",
        "https://youtube.com.evil.test/x",
        "https://user@youtube.com/x",
        "https://youtube.com:444/x",
        "--exec bad",
    ],
)
def test_media_target_rejects(url):
    with pytest.raises(UserError):
        media_target(url)


@pytest.mark.parametrize(
    "text",
    [
        "https://youtu.be/test",
        "https://www.youtube.com/watch?v=test",
        "https://soundcloud.com/user/song",
        "song name",
    ],
)
def test_media_target_accepts(text):
    assert media_target(text)


async def test_real_mp3_codec_and_send(ctx, tmp_path):
    output = tmp_path / "sample.mp3"
    await process(
        "ffmpeg",
        "-nostdin",
        "-v",
        "error",
        "-f",
        "lavfi",
        "-i",
        "sine=frequency=440:duration=0.2",
        "-c:a",
        "libmp3lame",
        str(output),
    )
    data = await probe(output)
    assert data["streams"][0]["codec_name"] == "mp3"
    await send_mp3(ctx, output)
    kwargs = ctx.client.send_file.call_args.kwargs
    assert kwargs["mime_type"] == "audio/mpeg" and kwargs["force_document"] is False
    assert kwargs["attributes"][0].__class__.__name__ == "DocumentAttributeAudio"


async def test_renamed_non_mp3_rejected(ctx, tmp_path):
    output = tmp_path / "fake.mp3"
    await process(
        "ffmpeg",
        "-nostdin",
        "-v",
        "error",
        "-f",
        "lavfi",
        "-i",
        "sine=frequency=440:duration=0.2",
        "-f",
        "wav",
        str(output),
    )
    with pytest.raises(UserError):
        await send_mp3(ctx, output)
    ctx.client.send_file.assert_not_awaited()


async def test_missing_mp3_rejected(ctx, tmp_path):
    with pytest.raises(UserError):
        await send_mp3(ctx, tmp_path / "missing.mp3")


async def media_fixture(ctx, tmp_path, kind):
    from unittest.mock import AsyncMock
    from types import SimpleNamespace as NS
    from PIL import Image

    path = tmp_path / ("sample.png" if kind == "image" else "sample.wav")
    if kind == "image":
        Image.new("RGB", (40, 20), (255, 100, 50)).save(path)
    else:
        await process(
            "ffmpeg",
            "-nostdin",
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:duration=0.2",
            str(path),
        )
    msg = ctx.event.get_reply_message.return_value
    msg.media = True
    msg.file = NS(size=path.stat().st_size)
    msg.download_media = AsyncMock(return_value=str(path))
    return path


@pytest.mark.parametrize(
    "name",
    [
        "tomp3",
        "dl",
        "mediainfo",
        "gray",
        "mirror",
        "flip",
        "blur",
        "rotate",
        "thumbnail",
        "invert",
    ],
)
async def test_media_handler_flows(ctx, tmp_path, name):
    import asyncio
    from nik.registry import COMMANDS

    await media_fixture(
        ctx, tmp_path, "audio" if name in ["tomp3", "dl", "mediainfo"] else "image"
    )
    await COMMANDS[name].handler(ctx)
    await asyncio.gather(*list(ctx.app.jobs.values()))
    messages = " ".join(c.args[1] for c in ctx.client.send_message.call_args_list)
    assert "⚠️" not in messages
    if name == "mediainfo":
        assert "pcm_s16le" in messages
    else:
        ctx.client.send_file.assert_awaited_once()


async def test_music_pipeline_with_local_audio(ctx, monkeypatch):
    import asyncio
    from pathlib import Path
    from nik.plugins import media
    from nik.registry import COMMANDS

    original = media.process

    async def substitute_downloader(*args, **kwargs):
        if "yt_dlp" in args:
            output = Path(args[args.index("-o") + 1].replace("%(ext)s", "mp3"))
            return await original(
                "ffmpeg",
                "-nostdin",
                "-v",
                "error",
                "-f",
                "lavfi",
                "-i",
                "sine=frequency=440:duration=0.2",
                "-c:a",
                "libmp3lame",
                str(output),
            )
        return await original(*args, **kwargs)

    monkeypatch.setattr(media, "process", substitute_downloader)
    ctx.args = "original permitted test audio"
    await COMMANDS["music"].handler(ctx)
    await asyncio.gather(*list(ctx.app.jobs.values()))
    assert ctx.client.send_file.call_args.kwargs["mime_type"] == "audio/mpeg"


async def test_qrcode(ctx):
    from nik.registry import COMMANDS

    ctx.args = "https://example.com"
    await COMMANDS["qrcode"].handler(ctx)
    buf = ctx.client.send_file.call_args.args[1]
    assert buf.getvalue().startswith(b"\x89PNG")
