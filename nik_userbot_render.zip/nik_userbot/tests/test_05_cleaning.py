import asyncio
from types import SimpleNamespace as NS
import pytest
from nik.registry import COMMANDS
from nik.core import UserError


@pytest.mark.parametrize("name", ["purge", "purgeme", "delmine", "deall"])
async def test_confirmation_then_bounded_delete(ctx, name):
    ctx.args = "3"
    ctx.client.history = [
        NS(id=i, sender_id=1 if i % 2 else 2) for i in range(499, 490, -1)
    ]
    await COMMANDS[name].handler(ctx)
    ctx.client.delete_messages.assert_not_awaited()
    ctx.args = next(iter(ctx.app.pending))
    await COMMANDS["confirm"].handler(ctx)
    await asyncio.gather(*list(ctx.app.jobs.values()))
    ids = ctx.client.delete_messages.call_args.args[1]
    assert len(ids) <= 3 and all(i < 500 for i in ids)
    if name != "purge":
        assert all(i % 2 for i in ids)


@pytest.mark.parametrize("count", ["0", "10000", "-1"])
async def test_invalid_count(ctx, count):
    ctx.args = count
    with pytest.raises(UserError):
        await COMMANDS["purge"].handler(ctx)
    ctx.client.delete_messages.assert_not_awaited()


async def test_job_cancellation(ctx):
    ctx.app.spawn("test", asyncio.sleep(1000))
    await COMMANDS["stopall"].handler(ctx)
    assert (
        not ctx.app.jobs
        and not ctx.store.get("filters")
        and not ctx.store.get("autobc")
    )


@pytest.mark.parametrize(
    "name,args",
    [
        ("hy", ""),
        ("del", ""),
        ("forward", "@guest"),
        ("save", ""),
        ("reply", "Hi there"),
        ("react", "👍"),
        ("unreact", ""),
        ("reactions", ""),
        ("read", ""),
        ("unread", ""),
        ("link", ""),
        ("quote", ""),
    ],
)
async def test_messaging_flows(ctx, name, args):
    ctx.args = args
    await COMMANDS[name].handler(ctx)
    assert ctx.client.send_message.await_count or ctx.client.requests
