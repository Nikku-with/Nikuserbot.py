import asyncio
import json
import os
import pytest
from nik.store import Store


async def test_persistence(tmp_path):
    one = Store(tmp_path)
    await one.set("sudo", [42])
    await one.set("notes", {"a": "हेलो"})
    two = Store(tmp_path)
    assert two.get("sudo") == [42] and two.get("notes") == {"a": "हेलो"}
    assert os.stat(two.path).st_mode & 0o777 == 0o600


async def test_concurrency(tmp_path):
    store = Store(tmp_path)
    await asyncio.gather(
        *(store.change("sudo", lambda ids, n=n: ids + [n]) for n in range(100))
    )
    assert len(store.get("sudo")) == 100
    assert len(json.loads(store.path.read_text())["sudo"]) == 100


async def test_get_is_copy(tmp_path):
    store = Store(tmp_path)
    value = store.get("notes")
    value["bad"] = 1
    assert not store.get("notes")


def test_corrupt_fail_closed(tmp_path):
    (tmp_path / "settings.json").write_text("{bad")
    with pytest.raises(ValueError):
        Store(tmp_path)
    assert (tmp_path / "settings.json").read_text() == "{bad"


async def test_failed_write_keeps_memory(tmp_path, monkeypatch):
    store = Store(tmp_path)

    def fail(*a):
        raise OSError("disk full")

    monkeypatch.setattr(os, "replace", fail)
    with pytest.raises(OSError):
        await store.set("sudo", [5])
    assert store.get("sudo") == []
