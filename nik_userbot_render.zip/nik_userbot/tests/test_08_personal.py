import pytest
from nik.registry import COMMANDS
from nik.store import Store


async def test_notes_roundtrip(ctx):
    ctx.args = "todo | test me"
    await COMMANDS["notesadd"].handler(ctx)
    assert Store(ctx.store.directory).get("notes")["todo"] == "test me"
    ctx.args = "todo"
    await COMMANDS["note"].handler(ctx)
    assert "test me" in ctx.client.send_message.call_args.args[1]
    await COMMANDS["notesdelete"].handler(ctx)
    assert not ctx.store.get("notes")


async def test_reminder_roundtrip(ctx):
    ctx.args = "10m task"
    await COMMANDS["remind"].handler(ctx)
    rows = Store(ctx.store.directory).get("reminders")
    assert len(rows) == 1
    ctx.args = rows[0]["id"]
    await COMMANDS["cancelremind"].handler(ctx)
    assert not ctx.store.get("reminders")


@pytest.mark.parametrize(
    "name,args",
    [("copy", "@guest"), ("cp", "@guest"), ("name", "New | Name"), ("bio", "New bio")],
)
async def test_profile_snapshot_not_overwritten(ctx, name, args):
    ctx.args = args
    await COMMANDS[name].handler(ctx)
    first = ctx.store.get("profile")
    assert first["first_name"] == "Owner"
    await COMMANDS[name].handler(ctx)
    assert ctx.store.get("profile") == first
    await COMMANDS["nrml"].handler(ctx)
    assert ctx.store.get("profile") is None


async def test_afk_roundtrip(ctx):
    ctx.args = "Lunch"
    await COMMANDS["afk"].handler(ctx)
    assert ctx.store.get("afk")["reason"] == "Lunch"
    await COMMANDS["unafk"].handler(ctx)
    assert ctx.store.get("afk") is None


@pytest.mark.parametrize(
    "name,args",
    [
        ("noteslist", ""),
        ("tasks", ""),
        ("block", "@guest"),
        ("unblock", "@guest"),
        ("unafk", ""),
    ],
)
async def test_personal_handlers(ctx, name, args):
    ctx.args = args
    await COMMANDS[name].handler(ctx)
    ctx.client.send_message.assert_awaited()


async def test_normal_alias(ctx):
    ctx.args = "New"
    await COMMANDS["name"].handler(ctx)
    await COMMANDS["normal"].handler(ctx)
    assert ctx.store.get("profile") is None


async def test_pfp_and_avatar(ctx, tmp_path):
    from PIL import Image
    from unittest.mock import AsyncMock

    path = tmp_path / "photo.jpg"
    Image.new("RGB", (10, 10)).save(path)
    msg = ctx.event.get_reply_message.return_value
    msg.photo = True
    msg.download_media = AsyncMock(return_value=str(path))
    await COMMANDS["pfp"].handler(ctx)
    assert ctx.store.get("profile")["added_photos"][0]["id"] == 5
    Image.new("RGB", (10, 10)).save(path)
    ctx.client.download_profile_photo.return_value = str(path)
    await COMMANDS["avatar"].handler(ctx)
    ctx.client.send_file.assert_awaited()
