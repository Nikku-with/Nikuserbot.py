from types import SimpleNamespace as NS
from unittest.mock import AsyncMock
import pytest
from telethon import types
from nik.core import App, Context
from nik.store import Store
from nik.plugins import load

load()


class FakeClient:
    def __init__(self):
        self.me = types.User(
            id=1, first_name="Owner", last_name="", username="owner", bot=False
        )
        self.user = types.User(
            id=2, first_name="Guest", last_name="", username="guest", bot=False
        )
        self.send_message = AsyncMock(return_value=NS(id=700, edit=AsyncMock()))
        self.send_file = AsyncMock()
        self.get_me = AsyncMock(return_value=self.me)
        self.get_entity = AsyncMock(side_effect=self.entity)
        self.get_permissions = AsyncMock(side_effect=self.permissions)
        for name in [
            "forward_messages",
            "delete_messages",
            "kick_participant",
            "edit_permissions",
            "edit_admin",
            "pin_message",
            "unpin_message",
            "delete_dialog",
            "send_read_acknowledge",
        ]:
            setattr(self, name, AsyncMock())
        self.get_participants = AsyncMock(return_value=[self.user])
        self.get_input_entity = AsyncMock(return_value=types.InputPeerUser(2, 0))
        self.download_profile_photo = AsyncMock(return_value=None)
        self.upload_file = AsyncMock()
        self.get_profile_photos = AsyncMock(return_value=[])
        self.requests = []
        self.history = []

    async def entity(self, raw):
        if raw == "me" or raw == 1:
            return self.me
        if raw == -100123:
            return NS(
                id=123,
                default_banned_rights=types.ChatBannedRights(
                    until_date=None, send_polls=True
                ),
            )
        return self.user

    async def permissions(self, chat, user):
        return NS(
            is_admin=user == 1,
            is_creator=user == 1,
            participant=NS(admin_rights=types.ChatAdminRights(delete_messages=True)),
        )

    async def __call__(self, request):
        self.requests.append(request)
        return NS(
            full_user=NS(about="Public bio"),
            photo=types.Photo(
                id=5, access_hash=6, file_reference=b"", date=None, sizes=[], dc_id=1
            ),
        )

    async def iter_messages(self, *args, **kwargs):
        limit = kwargs.get("limit", 100)
        rows = [
            x
            for x in self.history
            if x.id < kwargs.get("max_id", 99999) and x.id > kwargs.get("min_id", 0)
        ]
        if kwargs.get("from_user") == "me":
            rows = [x for x in rows if x.sender_id == 1]
        for row in rows[:limit]:
            yield row


@pytest.fixture
def ctx(tmp_path):
    client = FakeClient()
    store = Store(tmp_path)
    app = App(client, store)
    app.owner = 1
    reply = NS(
        id=10, sender_id=2, raw_text="Hello world", photo=None, media=None, file=None
    )
    event = NS(
        chat_id=-100123,
        sender_id=1,
        id=500,
        is_private=False,
        is_channel=True,
        is_reply=False,
        raw_text=".ping",
        chat=NS(id=123),
        mentioned=False,
        fwd_from=None,
    )
    event.get_reply_message = AsyncMock(return_value=reply)
    event.get_chat = AsyncMock(
        return_value=NS(id=123, title="Test group", username="testgroup")
    )
    event.get_sender = AsyncMock(return_value=client.user)
    event.message = reply
    return Context(app, event)
