import pytest
from nik.plugins.texttools import calculate, TRANSFORMS
from nik.core import UserError
from nik.registry import COMMANDS


@pytest.mark.parametrize(
    "expression,result",
    [
        ("2+3*4", 14),
        ("10//3", 3),
        ("-2**2", -4),
        ("(2+3)/2", 2.5),
        ("2**10", 1024),
        ("7%3", 1),
    ],
)
def test_calc(expression, result):
    assert calculate(expression) == result


@pytest.mark.parametrize(
    "expression",
    [
        '__import__("os")',
        "1/0",
        "2**1000000",
        "[1,2]",
        "(1).__class__",
        "True+1",
        "9" * 300,
        "(-1)**0.5",
    ],
)
def test_calc_blocks(expression):
    with pytest.raises(UserError):
        calculate(expression)


INPUTS = {
    "unbase64": "aGVsbG8=",
    "unhex": "68656c6c6f",
    "unbinary": "01101000 01101001",
    "json": '{"a":1}',
    "compactjson": '{"a":1}',
}


@pytest.mark.parametrize("name", list(TRANSFORMS))
async def test_every_transform_runs(ctx, name):
    ctx.args = INPUTS.get(name, "Hello World\nHello World")
    ctx.name = name
    await COMMANDS[name].handler(ctx)
    ctx.client.send_message.assert_awaited_once()
    assert "nik userbot" in ctx.client.send_message.call_args.args[1]


@pytest.mark.parametrize(
    "name,args",
    [
        ("replace", "Hello | Bye"),
        ("find", "Hello"),
        ("fancy", "Hi"),
        ("count", "Hi there"),
        ("uuid", ""),
        ("random", "1 10"),
        ("choose", "a | b"),
        ("roll", "6"),
        ("coin", ""),
        ("time", "Asia/Kolkata"),
        ("timestamp", "0"),
        ("password", "24"),
    ],
)
async def test_other_tools(ctx, name, args):
    ctx.args = args
    await COMMANDS[name].handler(ctx)
    assert ctx.client.send_message.await_count >= 1
