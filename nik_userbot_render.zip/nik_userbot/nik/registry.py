from dataclasses import dataclass
from typing import Callable


@dataclass(frozen=True)
class Command:
    name: str
    category: str
    usage: str
    description: str
    handler: Callable
    owner: bool = False


COMMANDS = {}


def command(name, category, usage, description, owner=False):
    def register(fn):
        if name in COMMANDS:
            raise ValueError(f"Duplicate command: {name}")
        COMMANDS[name] = Command(name, category, usage, description, fn, owner)
        return fn

    return register


def parse(text):
    if not text or not text.startswith(".") or text.startswith(".."):
        return None
    parts = text[1:].split(maxsplit=1)
    if not parts:
        return None
    return parts[0].lower(), parts[1].strip() if len(parts) > 1 else ""
