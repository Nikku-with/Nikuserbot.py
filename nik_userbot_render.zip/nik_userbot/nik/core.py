import asyncio
import html
import secrets
import time
from telethon import errors, utils


class UserError(Exception):
    pass


def esc(value):
    return html.escape(str(value))


class Context:
    def __init__(self, app, event, args="", name=""):
        self.app, self.event, self.args, self.name = app, event, args, name
        self.client, self.store = app.client, app.store
        self.chat = event.chat_id

    async def say(self, text, reply_to=None):
        # Always send a separate response: sudo messages cannot be edited by us.
        header = f'✦ <b>nik userbot</b> ━ <a href="tg://user?id={self.app.owner}">Owner</a>\n'
        # Bound payload before Telegram's UTF-16 limit; never truncate HTML tags.
        if len(text.encode("utf-16-le")) > 6500:
            import io

            plain = html.unescape(__import__("re").sub("<[^>]+>", "", text))
            file = io.BytesIO(plain.encode())
            file.name = "nik-result.txt"
            return await self.client.send_file(
                self.chat,
                file,
                caption=header + "📄 Result attached.",
                parse_mode="html",
            )
        return await self.client.send_message(
            self.chat,
            header + text,
            parse_mode="html",
            link_preview=False,
            reply_to=reply_to,
        )

    async def source(self, required=True):
        reply = await self.event.get_reply_message()
        if required and not reply:
            raise UserError("Reply to a message first. Use .help " + self.name)
        return reply

    async def text(self):
        if self.args:
            return self.args
        reply = await self.source()
        if not reply.raw_text:
            raise UserError("A text message is required.")
        return reply.raw_text

    async def target(self):
        reply = await self.source(False)
        if reply and reply.sender_id:
            return await self.client.get_entity(reply.sender_id)
        if not self.args:
            raise UserError("Reply to a user or provide @username / user ID.")
        key = self.args.split()[0]
        return await self.client.get_entity(
            int(key) if key.lstrip("-").isdigit() else key
        )

    async def admin(self):
        if self.event.is_private:
            raise UserError("Use this command in a group.")
        perms = await self.client.get_permissions(self.chat, self.app.owner)
        if not (perms.is_admin or perms.is_creator):
            raise UserError("Your account needs group admin permissions.")

    async def file(self, path, caption="📎 Ready", **kwargs):
        return await self.client.send_file(
            self.chat,
            path,
            caption=f'✦ <b>nik userbot</b> · <a href="tg://user?id={self.app.owner}">Owner</a>\n{caption}',
            parse_mode="html",
            **kwargs,
        )

    async def confirm(self, description, callback):
        token = secrets.token_hex(3)
        self.app.pending[token] = (
            time.monotonic() + 60,
            self.chat,
            self.event.sender_id,
            callback,
        )
        await self.say(
            f"⚠️ <b>{esc(description)}</b>\nExpires in 60 seconds. Confirm here: <code>.confirm {token}</code>"
        )


class App:
    def __init__(self, client, store):
        self.client, self.store = client, store
        self.owner = None
        self.started = time.monotonic()
        self.pending, self.jobs, self.cooldowns = {}, {}, {}
        self.semaphore = asyncio.Semaphore(4)
        self.command_lock = asyncio.Lock()

    def spawn(self, key, coroutine):
        if key in self.jobs and not self.jobs[key].done():
            coroutine.close()
            raise UserError("A job is already running. Use .stopall first.")
        task = asyncio.create_task(coroutine)
        self.jobs[key] = task

        def complete(t):
            if self.jobs.get(key) is t:
                self.jobs.pop(key, None)
            if not t.cancelled() and t.exception():
                import logging

                logging.getLogger("nik").error(
                    "Background job failed: %s", type(t.exception()).__name__
                )

        task.add_done_callback(complete)
        return task

    async def stop(self):
        tasks = list(self.jobs.values())
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self.jobs.clear()

    def allowed(self, scope, seconds=30):
        now = time.monotonic()
        previous = self.cooldowns.get(scope)
        if previous is not None and now - previous < seconds:
            return False
        self.cooldowns[scope] = now
        if len(self.cooldowns) > 10000:
            self.cooldowns = {
                k: v for k, v in self.cooldowns.items() if now - v < 86400
            }
        return True


async def resolve_chat(client, raw):
    return utils.get_peer_id(
        await client.get_entity(int(raw) if raw.lstrip("-").isdigit() else raw)
    )


async def safe_error(ctx, exc):
    if isinstance(exc, UserError):
        message = str(exc)
    elif isinstance(exc, errors.FloodWaitError):
        message = (
            f"Telegram rate limit: wait {exc.seconds} seconds. Do not retry rapidly."
        )
    elif isinstance(exc, errors.ChatAdminRequiredError):
        message = "Telegram requires additional admin rights for this action."
    elif isinstance(exc, (ValueError, TypeError)):
        message = "Invalid input or inaccessible user/chat. Check .help " + ctx.name
    elif isinstance(exc, errors.RPCError):
        message = f"Telegram rejected this request ({type(exc).__name__}). Check permissions and target."
    else:
        message = f"Could not complete ({type(exc).__name__}). Check service logs; no success was assumed."
    try:
        await ctx.say("⚠️ " + esc(message))
    except errors.RPCError:
        pass
