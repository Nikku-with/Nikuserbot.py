from importlib import import_module


def load():
    """Import plugins once; decorators register their real handlers."""
    for name in (
        "system",
        "messages",
        "moderation",
        "personal",
        "automation",
        "media",
        "texttools",
        "animations",
    ):
        import_module(f"{__name__}.{name}")
