import asyncio
from telethon import functions, types
from telethon.tl.functions.channels import InviteToChannelRequest
from ..core import UserError, esc
from ..registry import command


async def safe_target(ctx):
    await ctx.admin()
    user = await ctx.target()
    if user.id == ctx.app.owner:
        raise UserError("Cannot moderate your own account.")
    perms = await ctx.client.get_permissions(ctx.chat, user)
    if perms.is_admin or perms.is_creator:
        raise UserError("Target is an admin; no action taken.")
    return user


async def mod(ctx, action):
    user = await safe_target(ctx)
    if action == "kick":
        await ctx.client.kick_participant(ctx.chat, user)
    elif action == "ban":
        await ctx.client.edit_permissions(ctx.chat, user, view_messages=False)
    elif action == "unban":
        await ctx.client.edit_permissions(ctx.chat, user, view_messages=True)
    elif action in ("mute", "unmute"):
        if not ctx.event.is_channel:
            raise UserError("Individual restrictions require a supergroup.")
        permissions = await ctx.client.get_permissions(ctx.chat, user)
        rights = getattr(
            permissions.participant, "banned_rights", None
        ) or types.ChatBannedRights(until_date=None)
        if action == "mute":
            rights.send_messages = True
        else:
            if rights.view_messages:
                raise UserError("User is banned. Use .unban rather than .unmute.")
            for field in [
                "send_messages",
                "send_media",
                "send_stickers",
                "send_gifs",
                "send_games",
                "send_inline",
                "embed_links",
                "send_polls",
                "send_photos",
                "send_videos",
                "send_roundvideos",
                "send_audios",
                "send_voices",
                "send_docs",
                "send_plain",
            ]:
                setattr(rights, field, False)
        await ctx.client(
            functions.channels.EditBannedRequest(
                channel=ctx.chat, participant=user, banned_rights=rights
            )
        )
    await ctx.say(
        f'🛡️ <b>{esc(action)}</b> applied to <a href="tg://user?id={user.id}">user</a>. Group defaults still apply.'
    )


for action, desc in [
    ("kick", "Remove one member"),
    ("ban", "Ban one member"),
    ("unban", "Allow a banned user to rejoin"),
    ("mute", "Restrict one member from messaging"),
    ("unmute", "Remove an individual messaging restriction"),
]:

    async def handler(ctx, action=action):
        await mod(ctx, action)

    command(action, "Moderation", f".{action} @user or reply", desc, True)(handler)

for action in ["kick", "ban", "mute"]:

    async def handler(ctx, action=action):
        msg = await ctx.source()
        await mod(ctx, action)
        await ctx.client.delete_messages(ctx.chat, [msg.id])

    command(
        "del" + action,
        "Moderation",
        f".del{action} (reply)",
        f"{action.title()} sender, then delete replied message",
        True,
    )(handler)


@command("staff", "Moderation", ".staff", "List group administrators")
async def staff(ctx):
    if ctx.event.is_private:
        raise UserError("Use in a group.")
    users = await ctx.client.get_participants(
        ctx.chat, filter=types.ChannelParticipantsAdmins(), limit=100
    )
    await ctx.say(
        "🛡️ <b>Administrators</b>\n"
        + "\n".join(
            f'<a href="tg://user?id={u.id}">{esc(u.first_name or u.id)}</a>'
            for u in users
        )
    )


@command(
    "promote",
    "Moderation",
    ".promote @user or reply",
    "Grant limited delete/ban/pin admin rights",
    True,
)
async def promote(ctx):
    await ctx.admin()
    user = await ctx.target()
    await ctx.client.edit_admin(
        ctx.chat,
        user,
        change_info=False,
        post_messages=False,
        edit_messages=False,
        delete_messages=True,
        ban_users=True,
        invite_users=False,
        pin_messages=True,
        add_admins=False,
        manage_call=False,
    )
    await ctx.say("🛡️ Limited moderator rights granted.")


@command(
    "demote", "Moderation", ".demote @user or reply", "Remove admin privileges", True
)
async def demote(ctx):
    await ctx.admin()
    user = await ctx.target()
    if user.id == ctx.app.owner:
        raise UserError("Self-demotion is not supported.")
    await ctx.client.edit_admin(ctx.chat, user, is_admin=False)
    await ctx.say("🛡️ Admin privileges removed.")


@command("pin", "Moderation", ".pin (reply)", "Pin silently", True)
async def pin(ctx):
    await ctx.admin()
    msg = await ctx.source()
    await ctx.client.pin_message(ctx.chat, msg.id, notify=False)
    await ctx.say("📌 Pinned silently.")


@command("unpin", "Moderation", ".unpin (reply)", "Unpin one message", True)
async def unpin(ctx):
    await ctx.admin()
    msg = await ctx.source()
    await ctx.client.unpin_message(ctx.chat, msg.id)
    await ctx.say("📌 Unpinned.")


@command(
    "group",
    "Moderation",
    ".group title|desc text",
    "Set group title or description",
    True,
)
async def group(ctx):
    await ctx.admin()
    pair = ctx.args.split(maxsplit=1)
    if len(pair) != 2 or pair[0] not in ["title", "desc"]:
        raise UserError("Usage: .group title New name / .group desc Description")
    mode, value = pair
    if mode == "desc":
        await ctx.client(
            functions.messages.EditChatAboutRequest(peer=ctx.chat, about=value)
        )
    elif ctx.event.is_channel:
        await ctx.client(
            functions.channels.EditTitleRequest(channel=ctx.chat, title=value)
        )
    else:
        await ctx.client(
            functions.messages.EditChatTitleRequest(
                chat_id=(await ctx.event.get_chat()).id, title=value
            )
        )
    await ctx.say("🛡️ Group updated.")


LOCKS = {
    "messages": "send_messages",
    "media": "send_media",
    "stickers": "send_stickers",
    "gifs": "send_gifs",
    "polls": "send_polls",
    "links": "embed_links",
    "invites": "invite_users",
    "pins": "pin_messages",
    "info": "change_info",
}


async def lock_impl(ctx, value):
    await ctx.admin()
    field = LOCKS.get(ctx.args)
    if not field:
        raise UserError("Choose: " + ", ".join(LOCKS))
    chat = await ctx.client.get_entity(ctx.chat)
    rights = getattr(chat, "default_banned_rights", None) or types.ChatBannedRights(
        until_date=None
    )
    setattr(rights, field, value)
    await ctx.client(
        functions.messages.EditChatDefaultBannedRightsRequest(
            peer=ctx.chat, banned_rights=rights
        )
    )
    await ctx.say(
        "🔐 Default permission updated. Existing individual restrictions are unchanged."
    )


@command(
    "lock",
    "Moderation",
    ".lock messages|media|stickers|gifs|polls|links|invites|pins|info",
    "Restrict one group-default permission",
    True,
)
async def lock(ctx):
    await lock_impl(ctx, True)


@command(
    "unlock",
    "Moderation",
    ".unlock permission",
    "Allow one group-default permission",
    True,
)
async def unlock(ctx):
    await lock_impl(ctx, False)


@command("locks", "Moderation", ".locks", "Show default restrictions")
async def locks(ctx):
    chat = await ctx.client.get_entity(ctx.chat)
    rights = getattr(chat, "default_banned_rights", None)
    await ctx.say(
        "🔐 "
        + esc(
            "\n".join(
                f"{k}: {'locked' if getattr(rights, v, False) else 'allowed'}"
                for k, v in LOCKS.items()
            )
        )
    )


@command(
    "muteall",
    "Moderation",
    ".muteall",
    "Lock group messaging; save previous defaults",
    True,
)
async def muteall(ctx):
    await ctx.admin()
    chat = await ctx.client.get_entity(ctx.chat)
    old = getattr(chat, "default_banned_rights", None)
    if str(ctx.chat) in ctx.store.get("chat_backup"):
        raise UserError("Backup already exists. Use .unmuteall first.")
    rights = old or types.ChatBannedRights(until_date=None)
    values = {k: v for k, v in rights.to_dict().items() if k not in ["_", "until_date"]}
    await ctx.store.change("chat_backup", lambda d: {**d, str(ctx.chat): values})
    rights.send_messages = True
    await ctx.client(
        functions.messages.EditChatDefaultBannedRightsRequest(
            peer=ctx.chat, banned_rights=rights
        )
    )
    await ctx.say(
        "🔒 Group messaging locked. Admins are exempt; .unmuteall restores defaults."
    )


@command(
    "unmuteall", "Moderation", ".unmuteall", "Restore pre-muteall group defaults", True
)
async def unmuteall(ctx):
    await ctx.admin()
    saved = ctx.store.get("chat_backup").get(str(ctx.chat))
    if saved is None:
        raise UserError("No saved defaults. Use .unlock messages if appropriate.")
    await ctx.client(
        functions.messages.EditChatDefaultBannedRightsRequest(
            peer=ctx.chat,
            banned_rights=types.ChatBannedRights(until_date=None, **saved),
        )
    )
    await ctx.store.change(
        "chat_backup", lambda d: {k: v for k, v in d.items() if k != str(ctx.chat)}
    )
    await ctx.say("🔓 Original group defaults restored.")


@command(
    "join",
    "Chats",
    ".join @publicgroup or invite-link",
    "Join one group or request approval",
    True,
)
async def join(ctx):
    arg = ctx.args.strip()
    if not arg:
        raise UserError("Provide a group username or t.me invite link.")
    if "t.me/+" in arg or "t.me/joinchat/" in arg:
        token = arg.rstrip("/").split("/")[-1].lstrip("+")
        await ctx.client(functions.messages.ImportChatInviteRequest(hash=token))
    else:
        await ctx.client(functions.channels.JoinChannelRequest(channel=arg))
    await ctx.say("🔗 Join request submitted. Approval may be required.")


@command("leave", "Chats", ".leave", "Leave this group after confirmation", True)
async def leave(ctx):
    if ctx.event.is_private:
        raise UserError("Use in a group.")

    async def execute():
        await ctx.say("🔗 Leaving this group.")
        await ctx.client.delete_dialog(ctx.chat)

    await ctx.confirm("Leave this group?", execute)


@command(
    "invite",
    "Chats",
    ".invite @user",
    "Invite one user; privacy restrictions apply",
    True,
)
async def invite(ctx):
    await ctx.admin()
    user = await ctx.target()
    await invite_user(ctx, user)
    await ctx.say(
        "🔗 Invitation submitted; Telegram may require the user to join manually."
    )


async def invite_user(ctx, user):
    if ctx.event.is_channel:
        await ctx.client(InviteToChannelRequest(channel=ctx.chat, users=[user]))
    else:
        await ctx.client(
            functions.messages.AddChatUserRequest(
                chat_id=(await ctx.event.get_chat()).id, user_id=user, fwd_limit=0
            )
        )


@command(
    "addbots",
    "Chats",
    ".addbots @bot [@bot] (max 3)",
    "Invite explicitly named bots, without admin rights",
    True,
)
async def addbots(ctx):
    await ctx.admin()
    names = ctx.args.split()
    if not 1 <= len(names) <= 3:
        raise UserError("Specify 1–3 bot usernames.")
    result = []
    for name in names:
        try:
            user = await ctx.client.get_entity(name)
            if not getattr(user, "bot", False):
                raise UserError("not a bot")
            await invite_user(ctx, user)
            result.append(name + ": invited")
        except Exception as exc:
            result.append(name + ": failed (" + type(exc).__name__ + ")")
        await asyncio.sleep(2)
    await ctx.say("🤖 " + esc("\n".join(result)))


@command("invitebots", "Chats", ".invitebots @bot [@bot]", "Alias of addbots", True)
async def invitebots(ctx):
    await addbots(ctx)


@command(
    "rmbots",
    "Chats",
    ".rmbots @bot [@bot] (max 3)",
    "Remove explicitly named non-admin bots",
    True,
)
async def rmbots(ctx):
    await ctx.admin()
    names = ctx.args.split()
    if not 1 <= len(names) <= 3:
        raise UserError("Specify 1–3 bot usernames. No mass removal.")
    result = []
    for name in names:
        try:
            user = await ctx.client.get_entity(name)
            if not getattr(user, "bot", False):
                raise UserError("not a bot")
            perms = await ctx.client.get_permissions(ctx.chat, user)
            if perms.is_admin:
                raise UserError("admin bot protected")
            await ctx.client.kick_participant(ctx.chat, user)
            result.append(name + ": removed")
        except Exception as exc:
            result.append(name + ": failed (" + type(exc).__name__ + ")")
        await asyncio.sleep(2)
    await ctx.say("🤖 " + esc("\n".join(result)))


@command("bots", "Chats", ".bots", "List up to 100 bots in this group")
async def bots(ctx):
    if ctx.event.is_private:
        raise UserError("Use in a group.")
    users = await ctx.client.get_participants(
        ctx.chat, filter=types.ChannelParticipantsBots(), limit=100
    )
    await ctx.say(
        "🤖 "
        + esc(
            "\n".join("@" + u.username if u.username else str(u.id) for u in users)
            or "No bots."
        )
    )


@command("chatinfo", "Chats", ".chatinfo", "Show chat type and public details")
async def chatinfo(ctx):
    chat = await ctx.event.get_chat()
    await ctx.say(
        f"🔹 <b>{esc(getattr(chat, 'title', None) or 'Private chat')}</b>\nID: <code>{ctx.chat}</code>\nType: {type(chat).__name__}\nUsername: {esc(getattr(chat, 'username', None) or 'none')}"
    )


@command(
    "title",
    "Moderation",
    ".title @admin rank OR reply with .title rank",
    "Set an existing administrator’s group title",
    True,
)
async def title(ctx):
    await ctx.admin()
    if not ctx.event.is_channel:
        raise UserError("Custom titles require a supergroup.")
    if ctx.event.is_reply:
        user = await ctx.target()
        rank = ctx.args
    else:
        parts = ctx.args.split(maxsplit=1)
        if len(parts) != 2:
            raise UserError("Usage: .title @admin Moderator")
        user = await ctx.target()
        rank = parts[1]
    if not rank or len(rank) > 16:
        raise UserError("Provide a title of 1–16 characters.")
    perms = await ctx.client.get_permissions(ctx.chat, user)
    rights = getattr(perms.participant, "admin_rights", None)
    if not rights:
        raise UserError("Target must already be an administrator you can edit.")
    await ctx.client(
        functions.channels.EditAdminRequest(
            channel=ctx.chat, user_id=user, admin_rights=rights, rank=rank
        )
    )
    await ctx.say("🛡️ Administrator title updated; rights preserved.")


@command(
    "fullpromote",
    "Moderation",
    ".fullpromote @user or reply",
    "Confirm granting all standard group admin rights",
    True,
)
async def fullpromote(ctx):
    await ctx.admin()
    user = await ctx.target()

    async def execute():
        await ctx.client.edit_admin(
            ctx.chat,
            user,
            change_info=True,
            post_messages=True,
            edit_messages=True,
            delete_messages=True,
            ban_users=True,
            invite_users=True,
            pin_messages=True,
            add_admins=True,
            manage_call=True,
        )
        await ctx.say(
            "🛡️ Standard admin rights granted, including adding admins. Telegram may limit rights you can grant."
        )

    await ctx.confirm("Grant broad administrator rights to this user?", execute)
