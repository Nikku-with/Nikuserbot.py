import asyncio
from ..core import esc, UserError, safe_error
from ..registry import command

ANIMATIONS = {
    "love": [
        "🤍",
        "🤍 ✨",
        "🤍 ✨ 🤍",
        "✨ 🤍 ✨",
        "🤍 I",
        "🤍 I l",
        "🤍 I lo",
        "🤍 I lov",
        "🤍 I love",
        "🤍 I love y",
        "🤍 I love yo",
        "🤍 I love you",
        "💗 I love you ✨",
        "💖 I love you ✨",
        "💝 I love you ✨",
        "💎 I love you ✨",
        "✨ You matter",
        "✨ You matter 🤍",
        "🌙 Always rooting for you",
        "🌙 Always rooting for you 🤍",
        "💫 With love",
        "💫 With love 🤍",
        "💝 I love you 🤍",
    ],
    "heart": [("🤍 " * (1 + i % 5)).strip() + " ✨" for i in range(23)],
    "moon": [
        ("🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘")[i % 8] + " ✨ Night sky"
        for i in range(24)
    ],
    "loading": [
        "💠 [" + "▰" * (i // 2) + "▱" * (10 - i // 2) + f"] {i * 5}%" for i in range(21)
    ],
    "sparkle": [" " * (i % 8) + "✦ ✧ 💎 ✧ ✦" for i in range(24)],
    "countdown": ["⏳ " + str(i) for i in range(20, 0, -1)] + ["🎉 Complete"],
    "wave": ["🌊" * (1 + i % 5) + " 🐚" for i in range(24)],
    "bloom": [
        "🌱",
        "🌱 ✨",
        "🌿",
        "🌿 ✨",
        "☘️",
        "☘️ ✨",
        "🌷",
        "🌷 ✨",
        "🌸",
        "🌸 ✨",
        "🌺",
        "🌺 ✨",
        "🌻",
        "🌻 ✨",
        "🌼",
        "🌼 ✨",
        "🪷",
        "🪷 ✨",
        "💐",
        "💐 ✨",
        "💐 🌸 ✨",
    ],
}
for name, frames in ANIMATIONS.items():

    async def handler(ctx, frames=frames):
        if not ctx.app.allowed(("animation", ctx.chat), 90):
            raise UserError("Wait 90 seconds between animations in this chat.")

        async def run():
            try:
                msg = await ctx.say("✨ " + esc(frames[0]))
                for frame in frames[1:]:
                    await asyncio.sleep(3)
                    await msg.edit(
                        f'✦ <b>nik userbot</b> · <a href="tg://user?id={ctx.app.owner}">Owner</a>\n{esc(frame)}',
                        parse_mode="html",
                    )
            except Exception as exc:
                await safe_error(ctx, exc)

        ctx.app.spawn(f"animation:{ctx.chat}", run())

    command(
        name,
        "Animations",
        f".{name}",
        f"{len(frames)}-step single-message animation; 3s per frame",
    )(handler)


@command("animstop", "Animations", ".animstop", "Stop this chat’s active animation")
async def animstop(ctx):
    task = ctx.app.jobs.get(f"animation:{ctx.chat}")
    if task:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        await ctx.say("🛑 Animation stopped.")
    else:
        await ctx.say("✨ No animation running here.")
