import ast
import base64
import binascii
import codecs
import datetime
import hashlib
import html
import json
import math
import operator
import re
import secrets
import string
import uuid
from urllib.parse import quote, unquote
from zoneinfo import ZoneInfo
from ..core import UserError, esc
from ..registry import command

OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}


def calculate(text):
    if len(text) > 200:
        raise UserError("Expression is too long.")
    try:
        tree = ast.parse(text, mode="eval")
    except SyntaxError:
        raise UserError("Invalid arithmetic expression.") from None
    if len(list(ast.walk(tree))) > 60:
        raise UserError("Expression is too complex.")

    def walk(node):
        if isinstance(node, ast.Expression):
            return walk(node.body)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            value = node.value
        elif isinstance(node, ast.UnaryOp) and isinstance(
            node.op, (ast.UAdd, ast.USub)
        ):
            value = walk(node.operand) * (-1 if isinstance(node.op, ast.USub) else 1)
        elif isinstance(node, ast.BinOp) and type(node.op) in OPS:
            left, right = walk(node.left), walk(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 10:
                raise UserError("Exponent must be between -10 and 10.")
            try:
                value = OPS[type(node.op)](left, right)
            except (ZeroDivisionError, OverflowError):
                raise UserError("Undefined or oversized calculation.") from None
        else:
            raise UserError("Only numbers and arithmetic operators are allowed.")
        if (
            type(value) not in (int, float)
            or not math.isfinite(value)
            or abs(value) > 1e100
        ):
            raise UserError("Result is outside supported real-number range.")
        return value

    return walk(tree)


@command(
    "calc", "Utilities", ".calc arithmetic", "Safely calculate arithmetic without eval"
)
async def calc(ctx):
    await ctx.say("🧮 <code>" + esc(calculate(await ctx.text())) + "</code>")


def decode64(text):
    try:
        return base64.b64decode(text, validate=True).decode("utf-8")
    except (ValueError, UnicodeError, binascii.Error):
        raise UserError("Invalid UTF-8 base64.") from None


def words(text):
    return re.findall(r"\w+", text, flags=re.UNICODE)


def slug(text):
    return "-".join(words(text.lower()))


def prettyjson(text):
    try:
        return json.dumps(json.loads(text), ensure_ascii=False, indent=2)
    except ValueError:
        raise UserError("Invalid JSON.") from None


def parsebinary(text):
    try:
        return bytes(int(p, 2) for p in text.split()).decode("utf-8")
    except (ValueError, UnicodeError):
        raise UserError("Provide space-separated UTF-8 binary bytes.") from None


def parsehex(text):
    try:
        return bytes.fromhex(text).decode("utf-8")
    except (ValueError, UnicodeError):
        raise UserError("Invalid UTF-8 hexadecimal.") from None


TRANSFORMS = {
    "upper": ("Convert text to uppercase", str.upper),
    "lower": ("Convert text to lowercase", str.lower),
    "titlecase": ("Capitalise each word", str.title),
    "sentence": ("Capitalise the first character", str.capitalize),
    "swapcase": ("Swap upper/lowercase", str.swapcase),
    "reverse": ("Reverse Unicode codepoints", lambda s: s[::-1]),
    "trim": (
        "Trim whitespace from each line",
        lambda s: "\n".join(x.strip() for x in s.splitlines()),
    ),
    "oneline": ("Collapse whitespace into one line", lambda s: " ".join(s.split())),
    "sort": ("Sort lines ascending", lambda s: "\n".join(sorted(s.splitlines()))),
    "sortdesc": (
        "Sort lines descending",
        lambda s: "\n".join(sorted(s.splitlines(), reverse=True)),
    ),
    "unique": (
        "Remove duplicate lines, preserving order",
        lambda s: "\n".join(dict.fromkeys(s.splitlines())),
    ),
    "numberlines": (
        "Add line numbers",
        lambda s: "\n".join(f"{i}. {v}" for i, v in enumerate(s.splitlines(), 1)),
    ),
    "nonempty": (
        "Remove blank lines",
        lambda s: "\n".join(x for x in s.splitlines() if x.strip()),
    ),
    "wordcount": ("Count whitespace-delimited words", lambda s: str(len(s.split()))),
    "charcount": ("Count Unicode codepoints", lambda s: str(len(s))),
    "linecount": ("Count lines", lambda s: str(len(s.splitlines()))),
    "slug": ("Create a lowercase hyphenated slug", slug),
    "snake": ("Convert words to snake_case", lambda s: "_".join(words(s.lower()))),
    "camel": (
        "Convert words to lowerCamelCase",
        lambda s: "".join(
            w.lower() if i == 0 else w.title() for i, w in enumerate(words(s))
        ),
    ),
    "base64": (
        "Encode UTF-8 text as base64",
        lambda s: base64.b64encode(s.encode()).decode(),
    ),
    "unbase64": ("Decode UTF-8 base64", decode64),
    "hex": ("Encode UTF-8 text as hexadecimal", lambda s: s.encode().hex()),
    "unhex": ("Decode UTF-8 hexadecimal", parsehex),
    "binary": (
        "Encode UTF-8 text as binary bytes",
        lambda s: " ".join(f"{v:08b}" for v in s.encode()),
    ),
    "unbinary": ("Decode binary bytes as UTF-8 text", parsebinary),
    "urlencode": ("URL-encode text", lambda s: quote(s, safe="")),
    "urldecode": ("Decode URL escapes", unquote),
    "htmlencode": ("Display HTML-escaped text", html.escape),
    "htmldecode": ("Decode HTML entities", html.unescape),
    "rot13": ("Apply ROT13 to Latin letters", lambda s: codecs.encode(s, "rot_13")),
    "sha256": (
        "Calculate a SHA-256 text digest",
        lambda s: hashlib.sha256(s.encode()).hexdigest(),
    ),
    "sha512": (
        "Calculate a SHA-512 text digest",
        lambda s: hashlib.sha512(s.encode()).hexdigest(),
    ),
    "md5": (
        "Calculate MD5 checksum; not for password security",
        lambda s: hashlib.md5(s.encode(), usedforsecurity=False).hexdigest(),
    ),
    "json": ("Validate and pretty-print JSON", prettyjson),
    "compactjson": (
        "Validate and compact JSON",
        lambda s: json.dumps(json.loads(s), ensure_ascii=False, separators=(",", ":")),
    ),
    "extracturls": (
        "Extract HTTP(S) links from text",
        lambda s: "\n".join(re.findall(r"https?://[^\s<>]+", s)) or "No links found.",
    ),
    "extractemails": (
        "Extract email-like strings from supplied text",
        lambda s: (
            "\n".join(re.findall(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", s))
            or "No email addresses found."
        ),
    ),
}
for name, (desc, fn) in TRANSFORMS.items():

    async def handler(ctx, fn=fn):
        text = await ctx.text()
        if len(text) > 20000:
            raise UserError("Input limit: 20000 characters.")
        try:
            output = fn(text)
        except (ValueError, TypeError):
            raise UserError("Invalid input for this conversion.") from None
        await ctx.say("🔹 <pre>" + esc(output or "(empty result)") + "</pre>")

    command(name, "Text tools", f".{name} text or reply", desc)(handler)


@command(
    "replace",
    "Text tools",
    ".replace old | new (reply to text)",
    "Replace literal text, not regular expressions",
)
async def replace(ctx):
    old, sep, new = ctx.args.partition("|")
    if not sep or not old.strip():
        raise UserError("Example: .replace hello | hi (reply to text)")
    source = (await ctx.source()).raw_text or ""
    await ctx.say("🔹 " + esc(source.replace(old.strip(), new.strip())))


@command(
    "find",
    "Text tools",
    ".find literal (reply to text)",
    "Count case-sensitive literal occurrences",
)
async def find(ctx):
    if not ctx.args:
        raise UserError("Provide a literal search string.")
    await ctx.say(
        "🔎 "
        + str(((await ctx.source()).raw_text or "").count(ctx.args))
        + " occurrence(s)."
    )


@command(
    "fancy",
    "Text tools",
    ".fancy text or reply",
    "Render Latin letters in mathematical bold italic",
)
async def fancy(ctx):
    source = string.ascii_uppercase + string.ascii_lowercase
    dest = "".join(chr(0x1D468 + i) for i in range(26)) + "".join(
        chr(0x1D482 + i) for i in range(26)
    )
    await ctx.say(
        "🔹 " + esc((await ctx.text()).translate(str.maketrans(source, dest)))
    )


@command(
    "count",
    "Text tools",
    ".count text or reply",
    "Show characters, words, lines and UTF-8 size",
)
async def count(ctx):
    text = await ctx.text()
    await ctx.say(
        f"📐 Characters: {len(text)}\nWords: {len(text.split())}\nLines: {len(text.splitlines())}\nUTF-8 bytes: {len(text.encode())}"
    )


@command("uuid", "Utilities", ".uuid", "Generate a random UUID")
async def uuid_cmd(ctx):
    await ctx.say("🔹 <code>" + str(uuid.uuid4()) + "</code>")


@command(
    "random",
    "Utilities",
    ".random min max",
    "Generate a secure random integer in a bounded interval",
)
async def random(ctx):
    parts = ctx.args.split()
    if len(parts) != 2:
        raise UserError("Usage: .random 1 100")
    low, high = map(int, parts)
    if low > high or high - low > 10**18:
        raise UserError("Provide min ≤ max and range ≤ 10^18.")
    await ctx.say("🎲 " + str(low + secrets.randbelow(high - low + 1)))


@command("choose", "Utilities", ".choose option | option", "Choose one supplied option")
async def choose(ctx):
    choices = [v.strip() for v in ctx.args.split("|") if v.strip()]
    if len(choices) < 2:
        raise UserError("Supply at least two options separated by |")
    await ctx.say("💠 " + esc(secrets.choice(choices)))


@command("roll", "Utilities", ".roll [sides]", "Roll a die with 2–1000 sides")
async def roll(ctx):
    sides = int(ctx.args or 6)
    if not 2 <= sides <= 1000:
        raise UserError("Sides must be between 2 and 1000.")
    await ctx.say("🎲 " + str(1 + secrets.randbelow(sides)))


@command("coin", "Utilities", ".coin", "Flip a virtual coin")
async def coin(ctx):
    await ctx.say("🪙 " + secrets.choice(["Heads", "Tails"]))


@command(
    "time",
    "Utilities",
    ".time [IANA timezone]",
    "Show local time; defaults to Asia/Kolkata",
)
async def clock(ctx):
    try:
        zone = ZoneInfo(ctx.args or "Asia/Kolkata")
    except (ValueError, KeyError):
        raise UserError(
            "Unknown timezone. Example: Asia/Kolkata or Europe/London"
        ) from None
    await ctx.say("🕰️ " + esc(datetime.datetime.now(zone).isoformat(timespec="seconds")))


@command(
    "timestamp",
    "Utilities",
    ".timestamp [Unix seconds]",
    "Convert a timestamp to UTC or show current Unix seconds",
)
async def timestamp(ctx):
    if not ctx.args:
        text = str(int(datetime.datetime.now(datetime.timezone.utc).timestamp()))
    else:
        try:
            text = datetime.datetime.fromtimestamp(
                float(ctx.args), datetime.timezone.utc
            ).isoformat()
        except (ValueError, OverflowError, OSError):
            raise UserError("Timestamp is outside supported range.") from None
    await ctx.say("🕰️ " + esc(text))


@command(
    "password",
    "Security",
    ".password [length]",
    "Generate a password privately in Saved Messages",
    True,
)
async def password(ctx):
    length = int(ctx.args or 24)
    if not 12 <= length <= 128:
        raise UserError("Length must be 12–128.")
    value = "".join(
        secrets.choice(string.ascii_letters + string.digits + "-_.!")
        for _ in range(length)
    )
    await ctx.client.send_message(
        "me", "nik userbot · Generated password (private):\n" + value, parse_mode=None
    )
    await ctx.say(
        "🔐 Sent only to Saved Messages. Consider a password manager for long-term storage."
    )
