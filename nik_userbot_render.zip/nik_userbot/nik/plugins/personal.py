import time
from pathlib import Path
from telethon import functions
from ..core import UserError, esc
from ..registry import command


async def snapshot(ctx):
    if ctx.store.get("profile") is not None:
        return
    me = await ctx.client.get_me()
    full = await ctx.client(functions.users.GetFullUserRequest(id="me"))
    path = await ctx.client.download_profile_photo(
        "me", file=str(ctx.store.directory / "original-avatar.jpg")
    )
    await ctx.store.set(
        "profile",
        {
            "first_name": me.first_name or "",
            "last_name": me.last_name or "",
            "about": full.full_user.about or "",
            "photo": path,
            "added_photos": [],
        },
    )


async def upload_avatar(ctx, path):
    photo = await ctx.client(
        functions.photos.UploadProfilePhotoRequest(
            file=await ctx.client.upload_file(path)
        )
    )
    saved = ctx.store.get("profile")
    if saved is not None:
        saved["added_photos"].append(
            {
                "id": photo.photo.id,
                "access_hash": photo.photo.access_hash,
                "file_reference": photo.photo.file_reference.hex(),
            }
        )
        await ctx.store.set("profile", saved)


@command(
    "copy",
    "Profile",
    ".copy @user or reply",
    "Back up your profile then copy public name/bio/photo",
    True,
)
async def copy(ctx):
    user = await ctx.target()
    if user.id == ctx.app.owner:
        raise UserError("Choose another user.")
    await snapshot(ctx)
    full = await ctx.client(functions.users.GetFullUserRequest(id=user))
    await ctx.client(
        functions.account.UpdateProfileRequest(
            first_name=user.first_name or "nik",
            last_name=user.last_name or "",
            about=full.full_user.about or "",
        )
    )
    path = await ctx.client.download_profile_photo(
        user, file=str(ctx.store.directory / "copy-avatar.jpg")
    )
    try:
        if path:
            await upload_avatar(ctx, path)
    finally:
        if path:
            Path(path).unlink(missing_ok=True)
    await ctx.say(
        "🪞 Public profile copied. Use transparently, not to impersonate. Restore using .nrml."
    )


@command("cp", "Profile", ".cp @user or reply", "Alias of copy", True)
async def cp(ctx):
    await copy(ctx)


@command(
    "nrml",
    "Profile",
    ".nrml",
    "Restore original name/bio and remove added profile photos",
    True,
)
async def nrml(ctx):
    from telethon import types

    saved = ctx.store.get("profile")
    if not saved:
        raise UserError("No saved profile. Original profile was not guessed.")
    await ctx.client(
        functions.account.UpdateProfileRequest(
            first_name=saved["first_name"],
            last_name=saved["last_name"],
            about=saved["about"],
        )
    )
    # Resolve fresh photo references; old file references can expire.
    ids = {p["id"] for p in saved.get("added_photos", [])}
    photos = await ctx.client.get_profile_photos("me", limit=100)
    remove = [
        types.InputPhoto(p.id, p.access_hash, p.file_reference)
        for p in photos
        if p.id in ids
    ]
    if remove:
        await ctx.client(functions.photos.DeletePhotosRequest(id=remove))
    await ctx.store.set("profile", None)
    await ctx.say(
        "🪞 Name/bio restored; bot-added photos removed. Your previous photo remains if you did not delete it manually."
    )


@command("normal", "Profile", ".normal", "Alias of nrml", True)
async def normal(ctx):
    await nrml(ctx)


@command(
    "name",
    "Profile",
    ".name First | Last",
    "Update your display name with a backup",
    True,
)
async def name(ctx):
    if not ctx.args:
        raise UserError("Provide a nonempty display name.")
    first, _, last = ctx.args.partition("|")
    if not first.strip():
        raise UserError("First name cannot be empty.")
    await snapshot(ctx)
    await ctx.client(
        functions.account.UpdateProfileRequest(
            first_name=first.strip(), last_name=last.strip()
        )
    )
    await ctx.say("🪞 Display name updated.")


@command(
    "bio",
    "Profile",
    ".bio text or .bio -",
    "Update or clear your bio with a backup",
    True,
)
async def bio(ctx):
    if not ctx.args:
        raise UserError("Provide text; use - to clear.")
    await snapshot(ctx)
    await ctx.client(
        functions.account.UpdateProfileRequest(
            about="" if ctx.args == "-" else ctx.args
        )
    )
    await ctx.say("🪞 Bio updated.")


@command(
    "pfp",
    "Profile",
    ".pfp (reply to photo)",
    "Set a profile photo with restore tracking",
    True,
)
async def pfp(ctx):
    msg = await ctx.source()
    if not msg.photo:
        raise UserError("Reply to a Telegram photo, not an arbitrary file.")
    await snapshot(ctx)
    path = await msg.download_media(file=str(ctx.store.directory / "new-avatar.jpg"))
    try:
        await upload_avatar(ctx, path)
    finally:
        Path(path).unlink(missing_ok=True)
    await ctx.say("🪞 Profile photo updated.")


@command(
    "avatar",
    "Profile",
    ".avatar [@user] or reply",
    "Fetch an accessible public profile photo",
)
async def avatar(ctx):
    import tempfile

    target = await ctx.target() if ctx.args or ctx.event.is_reply else "me"
    with tempfile.TemporaryDirectory() as directory:
        path = await ctx.client.download_profile_photo(target, file=directory)
        if not path:
            raise UserError("No accessible profile photo.")
        await ctx.file(path, "🪞 Profile photo")


@command("afk", "Personal", ".afk [reason]", "Enable rate-limited away replies", True)
async def afk(ctx):
    await ctx.store.set(
        "afk", {"since": time.time(), "reason": ctx.args[:500] or "Away for now."}
    )
    await ctx.say("🌙 Away mode enabled. .unafk turns it off.")


@command("unafk", "Personal", ".unafk", "Disable away replies", True)
async def unafk(ctx):
    await ctx.store.set("afk", None)
    await ctx.say("💠 Away mode disabled.")


@command(
    "notesadd",
    "Notes",
    ".notesadd key | text or reply with .notesadd key",
    "Save a private named note",
    True,
)
async def notesadd(ctx):
    key, sep, text = ctx.args.partition("|")
    key = key.strip()
    if not key or len(key) > 60:
        raise UserError("Use a note name of 1–60 characters.")
    if not sep:
        text = (await ctx.source()).raw_text
    if not text or len(text) > 20000:
        raise UserError("Notes must contain 1–20000 characters.")
    await ctx.store.change("notes", lambda d: {**d, key: text.strip()})
    await ctx.say("🔖 Note saved privately.")


@command("noteslist", "Notes", ".noteslist", "List note names", True)
async def noteslist(ctx):
    await ctx.say("🔖 " + esc("\n".join(ctx.store.get("notes")) or "No notes."))


@command("note", "Notes", ".note key", "Show a saved note in this chat", True)
async def note(ctx):
    value = ctx.store.get("notes").get(ctx.args)
    if value is None:
        raise UserError("Note not found. See .noteslist")
    await ctx.say("🔖 " + esc(value))


@command("notesdelete", "Notes", ".notesdelete key", "Delete one saved note", True)
async def notesdelete(ctx):
    if ctx.args not in ctx.store.get("notes"):
        raise UserError("Note not found.")
    await ctx.store.change(
        "notes", lambda d: {k: v for k, v in d.items() if k != ctx.args}
    )
    await ctx.say("🧹 Note deleted.")


@command(
    "remind",
    "Notes",
    ".remind 10m text (s/m/h/d)",
    "Schedule a persisted reminder to Saved Messages",
    True,
)
async def remind(ctx):
    import re, secrets

    match = re.fullmatch(r"(\d+)([smhd])\s+(.+)", ctx.args, re.S)
    if not match:
        raise UserError("Example: .remind 10m Drink water")
    delay = int(match[1]) * {"s": 1, "m": 60, "h": 3600, "d": 86400}[match[2]]
    if not 30 <= delay <= 31536000:
        raise UserError("Use a delay between 30 seconds and 365 days.")
    if len(ctx.store.get("reminders")) >= 100:
        raise UserError("Maximum 100 pending reminders.")
    token = secrets.token_hex(3)
    await ctx.store.change(
        "reminders",
        lambda rows: (
            rows + [{"id": token, "at": time.time() + delay, "text": match[3][:2000]}]
        ),
    )
    await ctx.say(
        f"⏳ Reminder saved: <code>{token}</code>. Delivery requires worker online."
    )


@command("tasks", "Notes", ".tasks", "List pending persisted reminders", True)
async def tasks(ctx):
    rows = ctx.store.get("reminders")
    await ctx.say(
        "⏳ "
        + esc(
            "\n".join(
                f"{r['id']} · in {int(r['at'] - time.time())}s · {r['text']}"
                for r in rows
            )
            or "No reminders."
        )
    )


@command("cancelremind", "Notes", ".cancelremind id", "Cancel a reminder by ID", True)
async def cancelremind(ctx):
    if not any(r["id"] == ctx.args for r in ctx.store.get("reminders")):
        raise UserError("Reminder ID not found.")
    await ctx.store.change(
        "reminders", lambda rows: [r for r in rows if r["id"] != ctx.args]
    )
    await ctx.say("⏳ Reminder cancelled.")


@command(
    "block",
    "Personal",
    ".block @user or reply",
    "Block a user from contacting you",
    True,
)
async def block(ctx):
    user = await ctx.target()
    if user.id == ctx.app.owner:
        raise UserError("Cannot block yourself.")
    await ctx.client(functions.contacts.BlockRequest(id=user))
    await ctx.say("🔒 User blocked.")


@command("unblock", "Personal", ".unblock @user or reply", "Unblock a user", True)
async def unblock(ctx):
    await ctx.client(functions.contacts.UnblockRequest(id=await ctx.target()))
    await ctx.say("🔓 User unblocked.")
