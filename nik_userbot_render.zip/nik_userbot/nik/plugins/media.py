import asyncio
import io
import json
import os
import signal
import tempfile
from pathlib import Path
from urllib.parse import urlparse
from telethon import types
from ..core import UserError, esc, safe_error
from ..registry import command

LIMIT = 50 * 1024 * 1024
HOSTS = {
    "youtube.com",
    "www.youtube.com",
    "m.youtube.com",
    "youtu.be",
    "music.youtube.com",
    "soundcloud.com",
    "www.soundcloud.com",
}


def media_target(text):
    if not text or len(text) > 500:
        raise UserError("Provide a song name or supported YouTube/SoundCloud URL.")
    if "://" in text:
        url = urlparse(text)
        if (
            url.scheme != "https"
            or url.hostname not in HOSTS
            or url.username
            or url.password
            or url.port not in (None, 443)
        ):
            raise UserError(
                "Only HTTPS YouTube/SoundCloud URLs are supported; private/internal hosts are not accepted."
            )
        return text
    if text.startswith("-"):
        raise UserError("Search cannot start with a dash.")
    return "ytsearch1:" + text


async def process(*args, timeout=240):
    proc = await asyncio.create_subprocess_exec(
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        start_new_session=True,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout)
    except BaseException:
        if proc.returncode is None:
            os.killpg(proc.pid, signal.SIGKILL)
            await proc.wait()
        raise
    if proc.returncode:
        # Do not leak tokens, URLs or server filesystem paths in chat.
        raise UserError(
            "Media tool failed. Content may be restricted, unavailable or blocked from Render. No file was sent."
        )
    return stdout


async def probe(path):
    data = await process(
        "ffprobe",
        "-v",
        "error",
        "-show_format",
        "-show_streams",
        "-of",
        "json",
        str(path),
        timeout=30,
    )
    return json.loads(data)


async def send_mp3(ctx, path):
    if not path.exists() or path.stat().st_size > LIMIT:
        raise UserError("MP3 missing or exceeds the 50 MB safety limit.")
    metadata = await probe(path)
    streams = metadata.get("streams", [])
    if (
        not streams
        or any(s.get("codec_type") == "video" for s in streams)
        or not any(s.get("codec_name") == "mp3" for s in streams)
    ):
        raise UserError("Conversion verification failed: output is not audio-only MP3.")
    duration = int(float(metadata.get("format", {}).get("duration", 0)))
    await ctx.file(
        str(path),
        "🎧 <b>Audio-only MP3</b>",
        mime_type="audio/mpeg",
        force_document=False,
        attributes=[
            types.DocumentAttributeAudio(
                duration=duration, title=path.stem, performer="nik userbot"
            )
        ],
    )


async def background(ctx, fn):
    async def job():
        async with ctx.app.semaphore:
            try:
                await fn()
            except Exception as exc:
                await safe_error(ctx, exc)

    ctx.app.spawn(f"media:{ctx.chat}", job())
    await ctx.say(
        "🎧 Processing in background. Only download content you own or have permission to use. .stopall cancels."
    )


@command(
    "music",
    "Media",
    ".music song name or HTTPS YouTube/SoundCloud URL",
    "Download permitted audio and verify actual MP3",
)
async def music(ctx):
    target = media_target(ctx.args)

    async def run():
        with tempfile.TemporaryDirectory(prefix="nik-audio-") as directory:
            pattern = str(Path(directory) / "track.%(ext)s")
            await process(
                "python",
                "-m",
                "yt_dlp",
                "--ignore-config",
                "--js-runtimes",
                "node",
                "--no-playlist",
                "--no-progress",
                "--quiet",
                "--max-filesize",
                "50M",
                "--socket-timeout",
                "20",
                "--retries",
                "1",
                "--match-filter",
                "duration <= 900 & !is_live",
                "-f",
                "bestaudio/best",
                "-x",
                "--audio-format",
                "mp3",
                "--audio-quality",
                "192K",
                "-o",
                pattern,
                "--",
                target,
            )
            await send_mp3(ctx, Path(directory) / "track.mp3")

    await background(ctx, run)


async def download_reply(ctx, directory):
    msg = await ctx.source()
    if not msg.media or not msg.file:
        raise UserError("Reply to a downloadable media message.")
    chat = await ctx.event.get_chat()
    if getattr(chat, "noforwards", False) or getattr(msg, "noforwards", False):
        raise UserError("This chat protects its content. Download/resend is disabled.")
    if msg.file.size is None or msg.file.size > LIMIT:
        raise UserError("Input must be at most 50 MB with a known size.")
    path = await msg.download_media(file=directory)
    if not path:
        raise UserError("Media could not be downloaded.")
    return Path(path)


@command(
    "tomp3",
    "Media",
    ".tomp3 (reply to audio/video)",
    "Convert replied media into verified audio-only MP3",
)
async def tomp3(ctx):
    await ctx.source()

    async def run():
        with tempfile.TemporaryDirectory(prefix="nik-convert-") as directory:
            src = await download_reply(ctx, directory)
            output_dir = Path(directory) / "output"
            output_dir.mkdir()
            dest = output_dir / "converted.mp3"
            await process(
                "ffmpeg",
                "-nostdin",
                "-v",
                "error",
                "-y",
                "-i",
                str(src),
                "-map",
                "0:a:0",
                "-vn",
                "-t",
                "900",
                "-c:a",
                "libmp3lame",
                "-b:a",
                "192k",
                str(dest),
            )
            await send_mp3(ctx, dest)

    await background(ctx, run)


@command(
    "dl",
    "Media",
    ".dl (reply to media)",
    "Download and resend replied media, up to 50 MB",
)
async def dl(ctx):
    await ctx.source()

    async def run():
        with tempfile.TemporaryDirectory(prefix="nik-download-") as directory:
            path = await download_reply(ctx, directory)
            await ctx.file(str(path), "📥 Downloaded media", force_document=True)

    await background(ctx, run)


@command(
    "mediainfo",
    "Media",
    ".mediainfo (reply to media)",
    "Inspect codecs, duration and size with ffprobe",
)
async def mediainfo(ctx):
    await ctx.source()

    async def run():
        with tempfile.TemporaryDirectory() as directory:
            path = await download_reply(ctx, directory)
            info = await probe(path)
            data = {
                "bytes": path.stat().st_size,
                "duration": info.get("format", {}).get("duration"),
                "streams": [
                    {
                        "type": s.get("codec_type"),
                        "codec": s.get("codec_name"),
                        "width": s.get("width"),
                        "height": s.get("height"),
                    }
                    for s in info.get("streams", [])
                ],
            }
            await ctx.say("🎞️ <pre>" + esc(json.dumps(data, indent=2)) + "</pre>")

    await background(ctx, run)


@command("qrcode", "Media", ".qrcode text", "Create a QR code image")
async def qrcode(ctx):
    import qrcode

    text = await ctx.text()
    if len(text.encode()) > 1500:
        raise UserError("QR text must be under 1500 bytes.")
    image = await asyncio.to_thread(qrcode.make, text)
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    buf.seek(0)
    buf.name = "qr.png"
    await ctx.file(buf, "🔳 QR code")


async def image_action(ctx, action):
    from PIL import Image, ImageOps, ImageFilter

    with tempfile.TemporaryDirectory() as directory:
        src = await download_reply(ctx, directory)

        def convert():
            with Image.open(src) as original:
                if original.width * original.height > 20000000:
                    raise UserError("Image exceeds 20 megapixels.")
                image = ImageOps.exif_transpose(original).convert("RGB")
                if action == "gray":
                    image = ImageOps.grayscale(image)
                elif action == "mirror":
                    image = ImageOps.mirror(image)
                elif action == "flip":
                    image = ImageOps.flip(image)
                elif action == "blur":
                    image = image.filter(ImageFilter.GaussianBlur(8))
                elif action == "rotate":
                    image = image.rotate(90, expand=True)
                elif action == "thumbnail":
                    image.thumbnail((512, 512))
                elif action == "invert":
                    image = ImageOps.invert(image)
                dest = Path(directory) / "image-result.jpg"
                image.save(dest, quality=90)
                return dest

        dest = await asyncio.to_thread(convert)
        await ctx.file(str(dest), "🖼️ " + esc(action))


for name, desc in [
    ("gray", "Convert an image to grayscale"),
    ("mirror", "Mirror an image horizontally"),
    ("flip", "Flip an image vertically"),
    ("blur", "Blur an image"),
    ("rotate", "Rotate an image 90 degrees"),
    ("thumbnail", "Resize an image to fit 512×512"),
    ("invert", "Invert image colours"),
]:

    async def handler(ctx, action=name):
        await ctx.source()
        await background(ctx, lambda: image_action(ctx, action))

    command(name, "Images", f".{name} (reply to image)", desc)(handler)
