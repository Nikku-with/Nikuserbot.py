import io
import json
import time
from ..registry import command, COMMANDS
from ..core import UserError, esc


def menu_entries():
    specs = sorted(COMMANDS.values(), key=lambda x: (x.category, x.name))
    return [specs[i : i + 14] for i in range(0, len(specs), 14)]


async def menu_page(ctx, page):
    pages = menu_entries()
    if page < 1 or page > len(pages):
        raise UserError(f"Menu pages: 1–{len(pages)}")
    lines = [
        f"💎 <b>COMMAND DIRECTORY · {page}/{len(pages)}</b>",
        "━━━━━━━━━━━━━━━━━━━━",
    ]
    category = None
    for spec in pages[page - 1]:
        if category != spec.category:
            category = spec.category
            lines.append("\n🔹 <b>" + esc(category.upper()) + "</b>")
        lines.append(
            f"<code>.{spec.name}</code> {'🔐 ' if spec.owner else ''}— {esc(spec.description)}"
        )
    next_page = page + 1 if page < len(pages) else 1
    lines.append(
        f"\n✧ <code>.help command</code> for usage\n✧ <code>.menu {next_page}</code> for next page · 🔐 owner only"
    )
    await ctx.say("\n".join(lines))


@command("menu", "System", ".menu [page]", "Browse the live command directory")
async def menu(ctx):
    await menu_page(ctx, int(ctx.args or 1))


@command("menu2", "System", ".menu2", "Open directory page two")
async def menu2(ctx):
    await menu_page(ctx, 2)


@command("help", "System", ".help [command]", "Usage and permissions for a command")
async def help_cmd(ctx):
    if not ctx.args:
        return await menu_page(ctx, 1)
    spec = COMMANDS.get(ctx.args.lstrip(".").lower())
    if not spec:
        raise UserError("Unknown command. See .menu")
    await ctx.say(
        f"📖 <b>{esc(spec.name)}</b>\n{esc(spec.description)}\n<code>{esc(spec.usage)}</code>\nAccess: {'owner only' if spec.owner else 'owner / trusted sudo'}"
    )


@command("commands", "System", ".commands", "Export all real registered commands")
async def commands(ctx):
    data = "\n".join(
        f"{s.usage} — {s.description}" + (" [owner]" if s.owner else "")
        for s in sorted(COMMANDS.values(), key=lambda x: x.name)
    )
    buf = io.BytesIO(data.encode())
    buf.name = "commands.txt"
    await ctx.file(
        buf, f"📖 {len(COMMANDS)} registered commands (includes documented aliases)."
    )


@command("ping", "System", ".ping", "Measure a Telegram request round trip")
async def ping(ctx):
    begin = time.perf_counter()
    await ctx.client.get_me()
    await ctx.say(f"⚡ <b>{(time.perf_counter() - begin) * 1000:.0f} ms</b>")


@command("alive", "System", ".alive", "Check account connection")
async def alive(ctx):
    await ctx.say(
        "💠 <b>Connected</b> · " + str(len(COMMANDS)) + " registered commands."
    )


@command("uptime", "System", ".uptime", "Show time since this worker started")
async def uptime(ctx):
    await ctx.say(f"⏳ {int(time.monotonic() - ctx.app.started)} seconds online.")


@command("id", "System", ".id [@user] or reply", "Show a user ID")
async def identity(ctx):
    user = (
        await ctx.target()
        if ctx.args or ctx.event.is_reply
        else await ctx.client.get_me()
    )
    await ctx.say(f"🪪 <code>{user.id}</code>")


@command("chatid", "System", ".chatid", "Show this chat ID")
async def chatid(ctx):
    await ctx.say(f"🪪 <code>{ctx.chat}</code>")


@command("info", "System", ".info [@user] or reply", "Show public user information")
async def info(ctx):
    user = (
        await ctx.target()
        if ctx.args or ctx.event.is_reply
        else await ctx.client.get_me()
    )
    await ctx.say(
        f"🪪 <b>{esc(getattr(user, 'first_name', None) or getattr(user, 'title', ''))}</b>\nID: <code>{user.id}</code>\nUsername: {esc(getattr(user, 'username', None) or 'none')}\nBot: {getattr(user, 'bot', False)}"
    )


@command(
    "sudo",
    "Security",
    ".sudo @user or reply",
    "Grant trusted access; never share casually",
    True,
)
async def sudo(ctx):
    user = await ctx.target()
    if getattr(user, "bot", False):
        raise UserError("Bots cannot be sudo users.")
    await ctx.store.change("sudo", lambda ids: sorted(set(ids + [user.id])))
    await ctx.say(
        "🔐 Trusted user added. They can act through your account in accessible chats."
    )


@command(
    "delsudo", "Security", ".delsudo @user or reply", "Revoke trusted access", True
)
async def delsudo(ctx):
    user = await ctx.target()
    await ctx.store.change("sudo", lambda ids: [x for x in ids if x != user.id])
    await ctx.say("🔒 Access revoked.")


@command("sudolist", "Security", ".sudolist", "List trusted user IDs", True)
async def sudolist(ctx):
    await ctx.say(
        "🔐 <b>Trusted users</b>\n"
        + esc("\n".join(map(str, ctx.store.get("sudo"))) or "None")
    )


@command(
    "confirm",
    "Security",
    ".confirm token",
    "Approve a pending action in this chat",
    True,
)
async def confirm(ctx):
    # Do not consume a token on a mismatched-chat request.
    value = ctx.app.pending.get(ctx.args)
    if not value or value[0] < time.monotonic():
        ctx.app.pending.pop(ctx.args, None)
        raise UserError("Confirmation expired or unknown.")
    if value[1:3] != (ctx.chat, ctx.event.sender_id):
        raise UserError("Confirm from the original account and chat.")
    ctx.app.pending.pop(ctx.args)
    await value[3]()


@command("cancel", "Security", ".cancel", "Discard pending confirmations", True)
async def cancel(ctx):
    ctx.app.pending.clear()
    await ctx.say("🛑 Pending confirmations cleared.")


@command(
    "stopall", "System", ".stopall", "Stop jobs, broadcasts and automatic replies", True
)
async def stopall(ctx):
    await ctx.app.stop()
    for key, value in [
        ("autobc", None),
        ("autofw", {}),
        ("areply", {}),
        ("autoread", []),
        ("filters", {}),
        ("afk", None),
        ("reminders", []),
    ]:
        await ctx.store.set(key, value)
    ctx.app.pending.clear()
    await ctx.say("🛑 Jobs stopped; all automatic messaging and reminders disabled.")


@command("jobs", "System", ".jobs", "Show active background jobs", True)
async def jobs(ctx):
    await ctx.say("⚙️ " + esc(", ".join(ctx.app.jobs) or "No active jobs"))


@command(
    "backup", "Security", ".backup", "Send JSON state privately to Saved Messages", True
)
async def backup(ctx):
    buf = io.BytesIO(json.dumps(ctx.store.data, indent=2, ensure_ascii=False).encode())
    buf.name = "nik-settings-backup.json"
    await ctx.client.send_file(
        "me",
        buf,
        caption="nik userbot · private settings backup. No session credentials included.",
    )
    await ctx.say("🔐 Backup sent to Saved Messages. Treat it as private.")


@command("settings", "System", ".settings", "Show non-secret feature state", True)
async def settings(ctx):
    text = "\n".join(
        f"{key}: {len(ctx.store.get(key))}"
        for key in ["sudo", "notes", "filters", "broadcast", "reminders", "autofw"]
    )
    await ctx.say("⚙️ <b>Stored entries</b>\n" + esc(text))
