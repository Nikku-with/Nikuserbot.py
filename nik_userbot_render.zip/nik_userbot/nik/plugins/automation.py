import asyncio
import logging
import time
from telethon import errors
from ..core import Context, UserError, esc, resolve_chat
from ..registry import command, parse


async def permit(ctx):
    if ctx.event.is_private:
        if ctx.chat not in ctx.store.get("broadcast"):
            raise UserError(
                "Recipient must send .optin here first. They can send .optout anytime."
            )
    else:
        await ctx.admin()


@command(
    "optin",
    "Automation",
    ".optin (sent by recipient in private)",
    "Allow limited replies/broadcasts from this account",
)
async def optin(ctx):
    await ctx.say(
        "📨 The recipient must send .optin to this account in a private chat. Owners cannot opt others in."
    )


@command(
    "optout",
    "Automation",
    ".optout (sent by recipient in private)",
    "Revoke consent for replies/broadcasts",
)
async def optout(ctx):
    await ctx.say("📨 Recipients can send .optout privately at any time.")


@command(
    "filter",
    "Automation",
    ".filter trigger | response",
    "Add an exact-text reply in this permitted chat",
    True,
)
async def filter_add(ctx):
    await permit(ctx)
    trigger, sep, response = ctx.args.partition("|")
    trigger = trigger.strip().casefold()
    if not sep or not trigger or not response.strip():
        raise UserError("Usage: .filter hello | Hi there")
    if len(trigger) > 200 or len(response) > 1000:
        raise UserError("Trigger max 200; response max 1000 characters.")
    data = ctx.store.get("filters")
    rules = data.get(str(ctx.chat), {})
    rules[trigger] = response.strip()
    data[str(ctx.chat)] = rules
    await ctx.store.set("filters", data)
    await ctx.say(
        "💬 Exact-match filter saved. One automatic reply per chat per minute."
    )


@command(
    "filters",
    "Automation",
    ".filters",
    "List this chat’s exact-text reply triggers",
    True,
)
async def filters(ctx):
    await ctx.say(
        "💬 "
        + esc(
            "\n".join(ctx.store.get("filters").get(str(ctx.chat), {})) or "No filters."
        )
    )


@command(
    "unfilter", "Automation", ".unfilter trigger", "Remove one exact-text reply", True
)
async def unfilter(ctx):
    data = ctx.store.get("filters")
    rules = data.get(str(ctx.chat), {})
    trigger = ctx.args.casefold()
    if trigger not in rules:
        raise UserError("Trigger not found.")
    rules.pop(trigger)
    data[str(ctx.chat)] = rules
    await ctx.store.set("filters", data)
    await ctx.say("🧹 Filter removed.")


@command(
    "areply",
    "Automation",
    ".areply text",
    "Enable one reply per chat per minute with consent",
    True,
)
async def areply(ctx):
    await permit(ctx)
    if not ctx.args or len(ctx.args) > 1000:
        raise UserError("Provide 1–1000 characters.")
    await ctx.store.change("areply", lambda d: {**d, str(ctx.chat): ctx.args})
    await ctx.say("💬 Automatic reply enabled here; max once a minute.")


@command(
    "stopareply",
    "Automation",
    ".stopareply",
    "Disable this chat’s automatic reply",
    True,
)
async def stopareply(ctx):
    await ctx.store.change(
        "areply", lambda d: {k: v for k, v in d.items() if k != str(ctx.chat)}
    )
    await ctx.say("🛑 Automatic reply disabled here.")


@command(
    "autoread",
    "Automation",
    ".autoread on|off",
    "Toggle automatic read receipts in this chat",
    True,
)
async def autoread(ctx):
    if ctx.args not in ["on", "off"]:
        raise UserError("Usage: .autoread on or .autoread off")
    await ctx.store.change(
        "autoread",
        lambda ids: (
            sorted(set(ids + [ctx.chat]))
            if ctx.args == "on"
            else [x for x in ids if x != ctx.chat]
        ),
    )
    await ctx.say("📖 Autoread " + ctx.args)


@command(
    "bcadd",
    "Broadcasts",
    ".bcadd (in your administered group)",
    "Opt an administered group into broadcasts",
    True,
)
async def bcadd(ctx):
    if ctx.event.is_private:
        raise UserError("Private users must send .optin themselves.")
    await ctx.admin()
    await ctx.store.change("broadcast", lambda ids: sorted(set(ids + [ctx.chat])))
    await ctx.say("📨 Group opted in by its admin. .bcdel removes it.")


@command(
    "bcdel", "Broadcasts", ".bcdel [chat ID]", "Remove a broadcast destination", True
)
async def bcdel(ctx):
    target = int(ctx.args) if ctx.args else ctx.chat
    await revoke(ctx.app, target)
    await ctx.say(
        "🛑 Destination removed; its automatic replies and forwarding routes removed."
    )


@command("bclist", "Broadcasts", ".bclist", "List opted-in destination IDs", True)
async def bclist(ctx):
    await ctx.say(
        "📨 "
        + esc("\n".join(map(str, ctx.store.get("broadcast"))) or "No destinations.")
    )


async def broadcast(app, text):
    ok = 0
    failures = []
    for dest in app.store.get("broadcast")[:25]:
        if dest not in app.store.get("broadcast"):
            continue
        try:
            await app.client.send_message(
                dest,
                f'✦ <b>nik userbot</b> · <a href="tg://user?id={app.owner}">Owner</a>\n{esc(text)}\n\n📨 Private recipients: .optout to unsubscribe.',
                parse_mode="html",
            )
            ok += 1
        except errors.FloodWaitError:
            failures.append(f"{dest}: rate limit; stopped")
            break
        except Exception as exc:
            failures.append(f"{dest}: {type(exc).__name__}")
        await asyncio.sleep(5)
    await app.client.send_message(
        "me",
        f"nik userbot · Broadcast: {ok} sent; "
        + ("; ".join(failures) or "no failures"),
        parse_mode=None,
    )


@command(
    "bc",
    "Broadcasts",
    ".bc text",
    "One broadcast to up to 25 opted-in chats, 5s spacing",
    True,
)
async def bc(ctx):
    if not ctx.args or len(ctx.args) > 2000:
        raise UserError("Provide 1–2000 characters.")
    if not ctx.store.get("broadcast"):
        raise UserError("No opted-in destinations.")

    async def launch():
        if not ctx.app.allowed("broadcast", 3600):
            raise UserError("At most one broadcast per hour.")
        ctx.app.spawn("broadcast", broadcast(ctx.app, ctx.args))
        await ctx.say("📨 Broadcast started. Results go to Saved Messages.")

    await ctx.confirm("Broadcast to opted-in destinations?", launch)


@command(
    "autobc",
    "Broadcasts",
    ".autobc on hours | text OR off OR status",
    "Schedule broadcasts; minimum 6h, max 25 opted-in chats",
    True,
)
async def autobc(ctx):
    if ctx.args == "off":
        await ctx.store.set("autobc", None)
        await ctx.say(
            "🛑 Scheduled broadcasts off. .stopall also cancels an active job."
        )
        return
    if ctx.args == "status":
        value = ctx.store.get("autobc")
        await ctx.say("📨 " + esc(str(value) if value else "Disabled"))
        return
    left, sep, text = ctx.args.partition("|")
    args = left.split()
    if not sep or len(args) != 2 or args[0] != "on":
        raise UserError("Example: .autobc on 24 | Daily update")
    hours = float(args[1])
    if not 6 <= hours <= 8760 or not 1 <= len(text.strip()) <= 2000:
        raise UserError("Interval: 6–8760 hours; text: 1–2000 characters.")
    await ctx.store.set(
        "autobc",
        {
            "interval": hours * 3600,
            "next": time.time() + hours * 3600,
            "text": text.strip(),
        },
    )
    await ctx.say(
        "📨 Schedule saved. Only opted-in destinations receive it; first run after interval."
    )


@command(
    "autofw",
    "Forwarding",
    ".autofw add destination | off | list",
    "Forward from this group/channel to an opted-in chat, max 1/min",
    True,
)
async def autofw(ctx):
    if ctx.args == "list":
        return await ctx.say("📨 " + esc(str(ctx.store.get("autofw"))))
    if ctx.args == "off":
        await ctx.store.change(
            "autofw", lambda d: {k: v for k, v in d.items() if k != str(ctx.chat)}
        )
        return await ctx.say("🛑 This forwarding route disabled.")
    if not ctx.args.startswith("add "):
        raise UserError("Usage: .autofw add @destination / off / list")
    await ctx.admin()
    dest = await resolve_chat(ctx.client, ctx.args[4:].strip())
    if dest == ctx.chat or dest not in ctx.store.get("broadcast"):
        raise UserError("Destination must differ and be opted in via .optin or .bcadd.")
    routes = ctx.store.get("autofw")
    # Prevent cycles and cascades: destination cannot be a source, source cannot be a destination.
    if str(dest) in routes or ctx.chat in routes.values():
        raise UserError("Chained/cyclic routes are not supported.")
    routes[str(ctx.chat)] = dest
    await ctx.store.set("autofw", routes)
    await ctx.say(
        "📨 Route saved. New incoming non-command messages only; no history; max 1/minute."
    )


async def revoke(app, chat):
    await app.store.change("broadcast", lambda ids: [x for x in ids if x != chat])
    for key in ["areply", "filters"]:
        await app.store.change(
            key, lambda d: {k: v for k, v in d.items() if k != str(chat)}
        )
    await app.store.change(
        "autofw", lambda d: {k: v for k, v in d.items() if v != chat and k != str(chat)}
    )


async def incoming(app, event):
    if event.sender_id == app.owner or not event.sender_id:
        return
    sender = await event.get_sender()
    if getattr(sender, "bot", False):
        return
    text = (event.raw_text or "").strip()
    ctx = Context(app, event)
    if event.is_private and text.lower() in [".optin", ".optout"]:
        if text.lower() == ".optin":
            await app.store.change(
                "broadcast", lambda ids: sorted(set(ids + [event.chat_id]))
            )
            if app.allowed(("consent", event.chat_id), 30):
                await ctx.say(
                    "📨 You opted in to limited broadcasts/replies. Send .optout anytime."
                )
        else:
            await revoke(app, event.chat_id)
            if app.allowed(("consent", event.chat_id), 30):
                await ctx.say(
                    "🛑 Opted out. Broadcasts, configured replies and forwarding to you are disabled."
                )
        return
    if parse(text):
        return
    chat = event.chat_id
    if chat in app.store.get("autoread"):
        await app.client.send_read_acknowledge(chat, max_id=event.id)
    dest = app.store.get("autofw").get(str(chat))
    if (
        dest
        and dest in app.store.get("broadcast")
        and not event.fwd_from
        and app.allowed(("fw", chat), 60)
    ):
        await app.client.forward_messages(dest, event.message)
    consent = not event.is_private or chat in app.store.get("broadcast")
    answer = (
        app.store.get("filters").get(str(chat), {}).get(text.casefold())
        if consent
        else None
    )
    if not answer and consent:
        answer = app.store.get("areply").get(str(chat))
    afk = app.store.get("afk")
    if (
        not answer
        and afk
        and (event.is_private or event.mentioned)
        and app.allowed(("afk", chat), 3600)
    ):
        answer = f"Away · {afk['reason']}"
    if answer and app.allowed(("reply", chat), 60):
        await ctx.say("💬 " + esc(answer))


async def scheduler(app):
    while True:
        try:
            now = time.time()
            for row in app.store.get("reminders"):
                if row["at"] > now:
                    continue
                await app.client.send_message(
                    "me",
                    f'✦ <b>nik userbot</b> · <a href="tg://user?id={app.owner}">Owner</a>\n⏳ {esc(row["text"])}',
                    parse_mode="html",
                )
                await app.store.change(
                    "reminders", lambda rows: [r for r in rows if r["id"] != row["id"]]
                )
                await asyncio.sleep(2)
            value = app.store.get("autobc")
            if (
                value
                and now >= value["next"]
                and "broadcast" not in app.jobs
                and app.allowed("broadcast", 3600)
            ):
                value["next"] = now + value["interval"]
                await app.store.set("autobc", value)
                app.spawn("broadcast", broadcast(app, value["text"]))
        except errors.FloodWaitError as exc:
            await asyncio.sleep(min(exc.seconds, 3600))
        except Exception as exc:
            logging.getLogger("nik").warning(
                "Scheduler tick failed: %s", type(exc).__name__
            )
        await asyncio.sleep(15)
