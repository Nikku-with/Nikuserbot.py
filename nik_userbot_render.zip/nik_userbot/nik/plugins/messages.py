import asyncio
from telethon import functions, types
from ..core import UserError, esc, resolve_chat
from ..registry import command


@command("hy", "Messaging", ".hy", "Send a short greeting")
async def hy(ctx):
    await ctx.say("✦ Hello! Hope your day is going well. 💎")


@command("del", "Cleaning", ".del (reply)", "Delete one replied message", True)
async def delete(ctx):
    msg = await ctx.source()
    await ctx.client.delete_messages(ctx.chat, [msg.id], revoke=True)
    await ctx.say("🧹 Message deleted.")


async def purge_impl(ctx, own):
    reply = await ctx.source(False)
    if ctx.args:
        count = int(ctx.args)
        if not 1 <= count <= 9999:
            raise UserError("Count must be 1–9999.")
    elif reply:
        count = 9999
    else:
        raise UserError(
            "Provide a count (1–9999), or reply to the first message to delete."
        )
    if not own and not ctx.event.is_private:
        await ctx.admin()
    boundary = ctx.event.id
    lower = reply.id - 1 if reply else 0

    async def run():
        await ctx.say(
            "🧹 Cleanup started. .stopall cancels; deletions already made cannot be undone."
        )
        removed = 0
        batch = []
        async for msg in ctx.client.iter_messages(
            ctx.chat,
            limit=count,
            max_id=boundary,
            min_id=lower,
            from_user="me" if own else None,
        ):
            batch.append(msg.id)
            if len(batch) == 100:
                await ctx.client.delete_messages(ctx.chat, batch, revoke=True)
                removed += len(batch)
                batch = []
                await asyncio.sleep(2)
        if batch:
            await ctx.client.delete_messages(ctx.chat, batch, revoke=True)
            removed += len(batch)
        await ctx.say(f"🧹 Completed: {removed} messages submitted for deletion.")

    async def launch():
        async def guarded():
            from ..core import safe_error

            try:
                await run()
            except Exception as exc:
                await safe_error(ctx, exc)

        ctx.app.spawn(f"clean:{ctx.chat}", guarded())

    await ctx.confirm(
        f"Delete up to {count} {'own ' if own else ''}messages here? Irreversible.",
        launch,
    )


@command(
    "purge", "Cleaning", ".purge 1–9999 or reply", "Confirm a bounded cleanup", True
)
async def purge(ctx):
    await purge_impl(ctx, False)


@command(
    "purgeme",
    "Cleaning",
    ".purgeme 1–9999 or reply",
    "Delete only your messages after confirmation",
    True,
)
async def purgeme(ctx):
    await purge_impl(ctx, True)


@command("delmine", "Cleaning", ".delmine 1–9999 or reply", "Alias of purgeme", True)
async def delmine(ctx):
    await purge_impl(ctx, True)


@command(
    "deall",
    "Cleaning",
    ".deall [1–9999]",
    "Delete up to 9999 of your messages here, not all dialogs",
    True,
)
async def deall(ctx):
    if not ctx.args:
        ctx.args = "9999"
    await purge_impl(ctx, True)


@command(
    "forward",
    "Forwarding",
    ".forward @chat (reply)",
    "Forward one message to a chosen chat",
    True,
)
async def forward(ctx):
    msg = await ctx.source()
    if not ctx.args:
        raise UserError("Provide a destination @chat or ID.")
    target = await resolve_chat(ctx.client, ctx.args)
    await ctx.client.forward_messages(target, msg)
    await ctx.say("📨 Forwarded. Protected content cannot be forwarded.")


@command("save", "Forwarding", ".save (reply)", "Save a message to Saved Messages")
async def save(ctx):
    await ctx.client.forward_messages("me", await ctx.source())
    await ctx.say("🔖 Saved privately.")


@command("reply", "Messaging", ".reply text (reply)", "Send one non-automated reply")
async def reply(ctx):
    msg = await ctx.source()
    if not ctx.args:
        raise UserError("Provide reply text.")
    await ctx.say("💬 " + esc(ctx.args), reply_to=msg.id)


@command("react", "Reactions", ".react 👍 (reply)", "React once with a supported emoji")
async def react(ctx):
    msg = await ctx.source()
    if not ctx.args:
        raise UserError("Provide one emoji, e.g. 👍")
    await ctx.client(
        functions.messages.SendReactionRequest(
            peer=ctx.chat,
            msg_id=msg.id,
            reaction=[types.ReactionEmoji(emoticon=ctx.args)],
        )
    )
    await ctx.say("💠 Reaction sent.")


@command("unreact", "Reactions", ".unreact (reply)", "Remove your reaction")
async def unreact(ctx):
    msg = await ctx.source()
    await ctx.client(
        functions.messages.SendReactionRequest(
            peer=ctx.chat, msg_id=msg.id, reaction=[]
        )
    )
    await ctx.say("💠 Reaction removed.")


@command(
    "reactions", "Reactions", ".reactions (reply)", "Show reaction counts on a message"
)
async def reactions(ctx):
    msg = await ctx.source()
    rows = getattr(getattr(msg, "reactions", None), "results", []) or []
    await ctx.say(
        "💠 "
        + esc(
            "\n".join(
                f"{getattr(r.reaction, 'emoticon', 'custom emoji')}: {r.count}"
                for r in rows
            )
            or "No reactions."
        )
    )


@command("read", "Messaging", ".read", "Mark this chat read", True)
async def read(ctx):
    await ctx.client.send_read_acknowledge(ctx.chat)
    await ctx.say("📖 Marked read.")


@command("unread", "Messaging", ".unread", "Mark this dialog unread", True)
async def unread(ctx):
    await ctx.say("📌 Marking dialog unread.")
    peer = await ctx.client.get_input_entity(ctx.chat)
    await ctx.client(
        functions.messages.MarkDialogUnreadRequest(
            peer=types.InputDialogPeer(peer), unread=True
        )
    )


@command(
    "link", "Messaging", ".link (reply)", "Get a group message link when available"
)
async def link(ctx):
    msg = await ctx.source()
    chat = await ctx.event.get_chat()
    if getattr(chat, "username", None):
        url = f"https://t.me/{chat.username}/{msg.id}"
    elif ctx.event.is_channel:
        url = f"https://t.me/c/{chat.id}/{msg.id}"
    else:
        raise UserError("This chat has no supported message link.")
    await ctx.say("🔗 " + esc(url))


@command("quote", "Messaging", ".quote (reply)", "Quote text with sender attribution")
async def quote(ctx):
    msg = await ctx.source()
    await ctx.say(
        f'❝ {esc(msg.raw_text or "[non-text message]")} ❞\n— <a href="tg://user?id={msg.sender_id}">Sender</a>'
    )
