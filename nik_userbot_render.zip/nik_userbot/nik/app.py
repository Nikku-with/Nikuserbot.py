import asyncio
import logging
import os
import signal
from telethon import TelegramClient, events
from telethon.sessions import StringSession
from .core import App, Context, safe_error
from .registry import COMMANDS, parse
from .store import Store
from .plugins import load


async def main():
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s"
    )
    logging.getLogger("telethon").setLevel(logging.WARNING)
    missing = [
        key for key in ("API_ID", "API_HASH", "SESSION_STRING") if not os.getenv(key)
    ]
    if missing:
        raise SystemExit("Set Render environment variables: " + ", ".join(missing))
    try:
        session = StringSession(os.environ["SESSION_STRING"].strip())
        api_id = int(os.environ["API_ID"])
    except (ValueError, TypeError):
        raise SystemExit(
            "Invalid API_ID or session. Generate a TELETHON session locally."
        ) from None
    store = Store(os.getenv("DATA_DIR", "./data"))
    client = TelegramClient(
        session,
        api_id,
        os.environ["API_HASH"],
        flood_sleep_threshold=0,
        request_retries=1,
    )
    await client.connect()
    if not await client.is_user_authorized():
        await client.disconnect()
        raise SystemExit(
            "Session is not authorized. Regenerate it locally; no interactive login on Render."
        )
    me = await client.get_me()
    app = App(client, store)
    app.owner = me.id
    load()

    async def commands(event):
        await dispatch(app, event)

    from .plugins.automation import incoming, scheduler

    async def watcher(event):
        try:
            await incoming(app, event)
        except Exception as exc:
            logging.getLogger("nik").warning("Watcher failed: %s", type(exc).__name__)

    client.add_event_handler(commands, events.NewMessage())
    client.add_event_handler(watcher, events.NewMessage(incoming=True))
    scheduler_task = asyncio.create_task(scheduler(app))
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, lambda: asyncio.create_task(client.disconnect()))
    logging.info(
        "nik userbot online; %d registered commands. No session values logged.",
        len(COMMANDS),
    )
    try:
        await client.run_until_disconnected()
    finally:
        scheduler_task.cancel()
        await asyncio.gather(scheduler_task, return_exceptions=True)
        await app.stop()
        await client.disconnect()


async def dispatch(app, event):
    parsed = parse(event.raw_text)
    if not parsed or parsed[0] not in COMMANDS:
        return
    spec = COMMANDS[parsed[0]]
    if event.sender_id != app.owner and event.sender_id not in app.store.get(
        "sudo", []
    ):
        return
    ctx = Context(app, event, parsed[1], parsed[0])
    if spec.owner and event.sender_id != app.owner:
        await ctx.say("🔐 Owner-only command.")
        return
    if not app.allowed(("cmd", event.sender_id), 1):
        return
    async with app.command_lock:
        try:
            await spec.handler(ctx)
        except Exception as exc:
            logging.getLogger("nik").error(
                "Command %s failed: %s", spec.name, type(exc).__name__
            )
            await safe_error(ctx, exc)
