import asyncio
import copy
import json
import os
from pathlib import Path

DEFAULTS = {
    "sudo": [],
    "notes": {},
    "filters": {},
    "afk": None,
    "autoread": [],
    "areply": {},
    "broadcast": [],
    "autobc": None,
    "autofw": {},
    "reminders": [],
    "profile": None,
    "chat_backup": {},
}


class Store:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / "settings.json"
        self.lock = asyncio.Lock()
        self.data = copy.deepcopy(DEFAULTS)
        if self.path.exists():
            # Fail closed rather than silently overwriting corrupt permissions/state.
            value = json.loads(self.path.read_text())
            if not isinstance(value, dict):
                raise ValueError(
                    "settings.json must be a JSON object; restore your backup"
                )
            for key, default in DEFAULTS.items():
                if (
                    key in value
                    and default is not None
                    and not isinstance(value[key], type(default))
                ):
                    raise ValueError(f"Invalid settings field: {key}")
            self.data.update(value)

    def get(self, key, default=None):
        return copy.deepcopy(self.data.get(key, default))

    async def set(self, key, value):
        async with self.lock:
            data = copy.deepcopy(self.data)
            data[key] = copy.deepcopy(value)
            self._save(data)
            self.data = data

    async def change(self, key, fn):
        async with self.lock:
            data = copy.deepcopy(self.data)
            data[key] = fn(copy.deepcopy(data.get(key)))
            self._save(data)
            self.data = data

    def _save(self, data):
        temp = self.path.with_suffix(".tmp")
        with open(temp, "w") as stream:
            os.chmod(temp, 0o600)
            json.dump(data, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, self.path)
