"""nik userbot — fresh modular implementation."""
