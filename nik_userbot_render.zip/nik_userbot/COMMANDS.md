# nik userbot — Command reference

168 registered command names across 18 categories.

Four explicitly documented aliases: `cp`, `normal`, `delmine`, `invitebots`. `menu2` is a page-navigation shortcut. These are not counted as independent capabilities.

🔐 = owner only; all other commands require owner or trusted sudo, except private recipient `.optin` / `.optout` handled independently by the consent watcher.

## Animations

| Command / usage | What it does | Access |
|---|---|---|
| `.animstop` | Stop this chat’s active animation | Owner / sudo |
| `.bloom` | 21-step single-message animation; 3s per frame | Owner / sudo |
| `.countdown` | 21-step single-message animation; 3s per frame | Owner / sudo |
| `.heart` | 23-step single-message animation; 3s per frame | Owner / sudo |
| `.loading` | 21-step single-message animation; 3s per frame | Owner / sudo |
| `.love` | 23-step single-message animation; 3s per frame | Owner / sudo |
| `.moon` | 24-step single-message animation; 3s per frame | Owner / sudo |
| `.sparkle` | 24-step single-message animation; 3s per frame | Owner / sudo |
| `.wave` | 24-step single-message animation; 3s per frame | Owner / sudo |

## Automation

| Command / usage | What it does | Access |
|---|---|---|
| `.areply text` | Enable one reply per chat per minute with consent | 🔐 Owner |
| `.autoread on&#124;off` | Toggle automatic read receipts in this chat | 🔐 Owner |
| `.filter trigger &#124; response` | Add an exact-text reply in this permitted chat | 🔐 Owner |
| `.filters` | List this chat’s exact-text reply triggers | 🔐 Owner |
| `.optin (sent by recipient in private)` | Allow limited replies/broadcasts from this account | Owner / sudo |
| `.optout (sent by recipient in private)` | Revoke consent for replies/broadcasts | Owner / sudo |
| `.stopareply` | Disable this chat’s automatic reply | 🔐 Owner |
| `.unfilter trigger` | Remove one exact-text reply | 🔐 Owner |

## Broadcasts

| Command / usage | What it does | Access |
|---|---|---|
| `.autobc on hours &#124; text OR off OR status` | Schedule broadcasts; minimum 6h, max 25 opted-in chats | 🔐 Owner |
| `.bc text` | One broadcast to up to 25 opted-in chats, 5s spacing | 🔐 Owner |
| `.bcadd (in your administered group)` | Opt an administered group into broadcasts | 🔐 Owner |
| `.bcdel [chat ID]` | Remove a broadcast destination | 🔐 Owner |
| `.bclist` | List opted-in destination IDs | 🔐 Owner |

## Chats

| Command / usage | What it does | Access |
|---|---|---|
| `.addbots @bot [@bot] (max 3)` | Invite explicitly named bots, without admin rights | 🔐 Owner |
| `.bots` | List up to 100 bots in this group | Owner / sudo |
| `.chatinfo` | Show chat type and public details | Owner / sudo |
| `.invite @user` | Invite one user; privacy restrictions apply | 🔐 Owner |
| `.invitebots @bot [@bot]` | Alias of addbots | 🔐 Owner |
| `.join @publicgroup or invite-link` | Join one group or request approval | 🔐 Owner |
| `.leave` | Leave this group after confirmation | 🔐 Owner |
| `.rmbots @bot [@bot] (max 3)` | Remove explicitly named non-admin bots | 🔐 Owner |

## Cleaning

| Command / usage | What it does | Access |
|---|---|---|
| `.deall [1–9999]` | Delete up to 9999 of your messages here, not all dialogs | 🔐 Owner |
| `.del (reply)` | Delete one replied message | 🔐 Owner |
| `.delmine 1–9999 or reply` | Alias of purgeme | 🔐 Owner |
| `.purge 1–9999 or reply` | Confirm a bounded cleanup | 🔐 Owner |
| `.purgeme 1–9999 or reply` | Delete only your messages after confirmation | 🔐 Owner |

## Forwarding

| Command / usage | What it does | Access |
|---|---|---|
| `.autofw add destination &#124; off &#124; list` | Forward from this group/channel to an opted-in chat, max 1/min | 🔐 Owner |
| `.forward @chat (reply)` | Forward one message to a chosen chat | 🔐 Owner |
| `.save (reply)` | Save a message to Saved Messages | Owner / sudo |

## Images

| Command / usage | What it does | Access |
|---|---|---|
| `.blur (reply to image)` | Blur an image | Owner / sudo |
| `.flip (reply to image)` | Flip an image vertically | Owner / sudo |
| `.gray (reply to image)` | Convert an image to grayscale | Owner / sudo |
| `.invert (reply to image)` | Invert image colours | Owner / sudo |
| `.mirror (reply to image)` | Mirror an image horizontally | Owner / sudo |
| `.rotate (reply to image)` | Rotate an image 90 degrees | Owner / sudo |
| `.thumbnail (reply to image)` | Resize an image to fit 512×512 | Owner / sudo |

## Media

| Command / usage | What it does | Access |
|---|---|---|
| `.dl (reply to media)` | Download and resend replied media, up to 50 MB | Owner / sudo |
| `.mediainfo (reply to media)` | Inspect codecs, duration and size with ffprobe | Owner / sudo |
| `.music song name or HTTPS YouTube/SoundCloud URL` | Download permitted audio and verify actual MP3 | Owner / sudo |
| `.qrcode text` | Create a QR code image | Owner / sudo |
| `.tomp3 (reply to audio/video)` | Convert replied media into verified audio-only MP3 | Owner / sudo |

## Messaging

| Command / usage | What it does | Access |
|---|---|---|
| `.hy` | Send a short greeting | Owner / sudo |
| `.link (reply)` | Get a group message link when available | Owner / sudo |
| `.quote (reply)` | Quote text with sender attribution | Owner / sudo |
| `.read` | Mark this chat read | 🔐 Owner |
| `.reply text (reply)` | Send one non-automated reply | Owner / sudo |
| `.unread` | Mark this dialog unread | 🔐 Owner |

## Moderation

| Command / usage | What it does | Access |
|---|---|---|
| `.ban @user or reply` | Ban one member | 🔐 Owner |
| `.delban (reply)` | Ban sender, then delete replied message | 🔐 Owner |
| `.delkick (reply)` | Kick sender, then delete replied message | 🔐 Owner |
| `.delmute (reply)` | Mute sender, then delete replied message | 🔐 Owner |
| `.demote @user or reply` | Remove admin privileges | 🔐 Owner |
| `.fullpromote @user or reply` | Confirm granting all standard group admin rights | 🔐 Owner |
| `.group title&#124;desc text` | Set group title or description | 🔐 Owner |
| `.kick @user or reply` | Remove one member | 🔐 Owner |
| `.lock messages&#124;media&#124;stickers&#124;gifs&#124;polls&#124;links&#124;invites&#124;pins&#124;info` | Restrict one group-default permission | 🔐 Owner |
| `.locks` | Show default restrictions | Owner / sudo |
| `.mute @user or reply` | Restrict one member from messaging | 🔐 Owner |
| `.muteall` | Lock group messaging; save previous defaults | 🔐 Owner |
| `.pin (reply)` | Pin silently | 🔐 Owner |
| `.promote @user or reply` | Grant limited delete/ban/pin admin rights | 🔐 Owner |
| `.staff` | List group administrators | Owner / sudo |
| `.title @admin rank OR reply with .title rank` | Set an existing administrator’s group title | 🔐 Owner |
| `.unban @user or reply` | Allow a banned user to rejoin | 🔐 Owner |
| `.unlock permission` | Allow one group-default permission | 🔐 Owner |
| `.unmute @user or reply` | Remove an individual messaging restriction | 🔐 Owner |
| `.unmuteall` | Restore pre-muteall group defaults | 🔐 Owner |
| `.unpin (reply)` | Unpin one message | 🔐 Owner |

## Notes

| Command / usage | What it does | Access |
|---|---|---|
| `.cancelremind id` | Cancel a reminder by ID | 🔐 Owner |
| `.note key` | Show a saved note in this chat | 🔐 Owner |
| `.notesadd key &#124; text or reply with .notesadd key` | Save a private named note | 🔐 Owner |
| `.notesdelete key` | Delete one saved note | 🔐 Owner |
| `.noteslist` | List note names | 🔐 Owner |
| `.remind 10m text (s/m/h/d)` | Schedule a persisted reminder to Saved Messages | 🔐 Owner |
| `.tasks` | List pending persisted reminders | 🔐 Owner |

## Personal

| Command / usage | What it does | Access |
|---|---|---|
| `.afk [reason]` | Enable rate-limited away replies | 🔐 Owner |
| `.block @user or reply` | Block a user from contacting you | 🔐 Owner |
| `.unafk` | Disable away replies | 🔐 Owner |
| `.unblock @user or reply` | Unblock a user | 🔐 Owner |

## Profile

| Command / usage | What it does | Access |
|---|---|---|
| `.avatar [@user] or reply` | Fetch an accessible public profile photo | Owner / sudo |
| `.bio text or .bio -` | Update or clear your bio with a backup | 🔐 Owner |
| `.copy @user or reply` | Back up your profile then copy public name/bio/photo | 🔐 Owner |
| `.cp @user or reply` | Alias of copy | 🔐 Owner |
| `.name First &#124; Last` | Update your display name with a backup | 🔐 Owner |
| `.normal` | Alias of nrml | 🔐 Owner |
| `.nrml` | Restore original name/bio and remove added profile photos | 🔐 Owner |
| `.pfp (reply to photo)` | Set a profile photo with restore tracking | 🔐 Owner |

## Reactions

| Command / usage | What it does | Access |
|---|---|---|
| `.react 👍 (reply)` | React once with a supported emoji | Owner / sudo |
| `.reactions (reply)` | Show reaction counts on a message | Owner / sudo |
| `.unreact (reply)` | Remove your reaction | Owner / sudo |

## Security

| Command / usage | What it does | Access |
|---|---|---|
| `.backup` | Send JSON state privately to Saved Messages | 🔐 Owner |
| `.cancel` | Discard pending confirmations | 🔐 Owner |
| `.confirm token` | Approve a pending action in this chat | 🔐 Owner |
| `.delsudo @user or reply` | Revoke trusted access | 🔐 Owner |
| `.password [length]` | Generate a password privately in Saved Messages | 🔐 Owner |
| `.sudo @user or reply` | Grant trusted access; never share casually | 🔐 Owner |
| `.sudolist` | List trusted user IDs | 🔐 Owner |

## System

| Command / usage | What it does | Access |
|---|---|---|
| `.alive` | Check account connection | Owner / sudo |
| `.chatid` | Show this chat ID | Owner / sudo |
| `.commands` | Export all real registered commands | Owner / sudo |
| `.help [command]` | Usage and permissions for a command | Owner / sudo |
| `.id [@user] or reply` | Show a user ID | Owner / sudo |
| `.info [@user] or reply` | Show public user information | Owner / sudo |
| `.jobs` | Show active background jobs | 🔐 Owner |
| `.menu [page]` | Browse the live command directory | Owner / sudo |
| `.menu2` | Open directory page two | Owner / sudo |
| `.ping` | Measure a Telegram request round trip | Owner / sudo |
| `.settings` | Show non-secret feature state | 🔐 Owner |
| `.stopall` | Stop jobs, broadcasts and automatic replies | 🔐 Owner |
| `.uptime` | Show time since this worker started | Owner / sudo |

## Text tools

| Command / usage | What it does | Access |
|---|---|---|
| `.base64 text or reply` | Encode UTF-8 text as base64 | Owner / sudo |
| `.binary text or reply` | Encode UTF-8 text as binary bytes | Owner / sudo |
| `.camel text or reply` | Convert words to lowerCamelCase | Owner / sudo |
| `.charcount text or reply` | Count Unicode codepoints | Owner / sudo |
| `.compactjson text or reply` | Validate and compact JSON | Owner / sudo |
| `.count text or reply` | Show characters, words, lines and UTF-8 size | Owner / sudo |
| `.extractemails text or reply` | Extract email-like strings from supplied text | Owner / sudo |
| `.extracturls text or reply` | Extract HTTP(S) links from text | Owner / sudo |
| `.fancy text or reply` | Render Latin letters in mathematical bold italic | Owner / sudo |
| `.find literal (reply to text)` | Count case-sensitive literal occurrences | Owner / sudo |
| `.hex text or reply` | Encode UTF-8 text as hexadecimal | Owner / sudo |
| `.htmldecode text or reply` | Decode HTML entities | Owner / sudo |
| `.htmlencode text or reply` | Display HTML-escaped text | Owner / sudo |
| `.json text or reply` | Validate and pretty-print JSON | Owner / sudo |
| `.linecount text or reply` | Count lines | Owner / sudo |
| `.lower text or reply` | Convert text to lowercase | Owner / sudo |
| `.md5 text or reply` | Calculate MD5 checksum; not for password security | Owner / sudo |
| `.nonempty text or reply` | Remove blank lines | Owner / sudo |
| `.numberlines text or reply` | Add line numbers | Owner / sudo |
| `.oneline text or reply` | Collapse whitespace into one line | Owner / sudo |
| `.replace old &#124; new (reply to text)` | Replace literal text, not regular expressions | Owner / sudo |
| `.reverse text or reply` | Reverse Unicode codepoints | Owner / sudo |
| `.rot13 text or reply` | Apply ROT13 to Latin letters | Owner / sudo |
| `.sentence text or reply` | Capitalise the first character | Owner / sudo |
| `.sha256 text or reply` | Calculate a SHA-256 text digest | Owner / sudo |
| `.sha512 text or reply` | Calculate a SHA-512 text digest | Owner / sudo |
| `.slug text or reply` | Create a lowercase hyphenated slug | Owner / sudo |
| `.snake text or reply` | Convert words to snake_case | Owner / sudo |
| `.sort text or reply` | Sort lines ascending | Owner / sudo |
| `.sortdesc text or reply` | Sort lines descending | Owner / sudo |
| `.swapcase text or reply` | Swap upper/lowercase | Owner / sudo |
| `.titlecase text or reply` | Capitalise each word | Owner / sudo |
| `.trim text or reply` | Trim whitespace from each line | Owner / sudo |
| `.unbase64 text or reply` | Decode UTF-8 base64 | Owner / sudo |
| `.unbinary text or reply` | Decode binary bytes as UTF-8 text | Owner / sudo |
| `.unhex text or reply` | Decode UTF-8 hexadecimal | Owner / sudo |
| `.unique text or reply` | Remove duplicate lines, preserving order | Owner / sudo |
| `.upper text or reply` | Convert text to uppercase | Owner / sudo |
| `.urldecode text or reply` | Decode URL escapes | Owner / sudo |
| `.urlencode text or reply` | URL-encode text | Owner / sudo |
| `.wordcount text or reply` | Count whitespace-delimited words | Owner / sudo |

## Utilities

| Command / usage | What it does | Access |
|---|---|---|
| `.calc arithmetic` | Safely calculate arithmetic without eval | Owner / sudo |
| `.choose option &#124; option` | Choose one supplied option | Owner / sudo |
| `.coin` | Flip a virtual coin | Owner / sudo |
| `.random min max` | Generate a secure random integer in a bounded interval | Owner / sudo |
| `.roll [sides]` | Roll a die with 2–1000 sides | Owner / sudo |
| `.time [IANA timezone]` | Show local time; defaults to Asia/Kolkata | Owner / sudo |
| `.timestamp [Unix seconds]` | Convert a timestamp to UTC or show current Unix seconds | Owner / sudo |
| `.uuid` | Generate a random UUID | Owner / sudo |
