# ✦ nik userbot

Fresh modular Telegram userbot project. **168 registered command names in 18 categories**, generated from real registered handlers—not a hardcoded marketing menu. Four documented aliases and the `.menu2` navigation shortcut are included in that count. See [COMMANDS.md](COMMANDS.md) for the complete inventory and exact usage.

**Scope:** personal utilities, legitimate moderation, consent-based messaging, MP3 media, profile backup/restore, persistent notes, and single-message animations. Targeted abusive raids, harassment floods, mass kicks/bans and unsolicited bulk messaging are intentionally absent. This is not a drop-in replacement for every legacy raid script.

## Before deploying

- This operates **your Telegram account**, not a BotFather bot. Telegram may restrict accounts for automation or excessive requests. Rate limits reduce risk; they do not guarantee immunity.
- **Only three credentials:** `API_ID`, `API_HASH`, `SESSION_STRING`. Owner ID is detected at login. No second account, hardcoded owner ID or Gemini key is required.
- **TELETHON session required.** A Pyrogram session from an old script will not work here. Generate a fresh compatible session locally if necessary.
- A session string grants account access. Never paste it into chat, source code, screenshots or GitHub. If a session was exposed previously, terminate it in Telegram Settings → Devices and generate a new one.
- Use one running instance only. Do not run the same session in multiple deployments.

## Render deployment — chosen configuration

Use a **paid Docker background worker with a persistent disk**. This project is not a free web-service keep-alive workaround. A background worker needs no HTTP port, Flask server or artificial uptime pings.

1. Unzip the project. Upload **the entire project directory's contents** to a private GitHub repository. `main.py` and `requirements.txt` alone are **not sufficient**: include `nik/`, `Dockerfile`, `render.yaml` and the other project files.
2. In Render, choose **New → Blueprint**, connect the repository, and select this `render.yaml`.
3. Confirm the paid worker plan and persistent-disk charges in Render before creating the service. The blueprint selects `starter` and a 1 GB disk; it does not provide billing or a free deployment.
4. Supply these **secret environment variables** in Render:

   | Variable | Value |
   |---|---|
   | `API_ID` | Your numeric Telegram API ID |
   | `API_HASH` | Your Telegram API hash |
   | `SESSION_STRING` | Authorized Telethon StringSession |

   The blueprint also sets non-secret `DATA_DIR=/var/data/nik` and mounts a disk at `/var/data`.
5. Deploy. Docker installs Python, FFmpeg/FFprobe, Node.js and the pinned Python dependencies.
6. Start command is **`python main.py`**, already configured as Docker `CMD`. `start.sh` contains the same command. Leave Docker command override empty, or use that command if manually configuring it.
7. Check logs for `nik userbot online; 168 registered commands`. In **Saved Messages**, send `.ping`, wait a second, then `.menu`.

Render's filesystem is ephemeral unless data is written under a persistent disk mount. The disk is the reason JSON settings survive redeploys/restarts. Reference: https://render.com/docs/disks and https://render.com/docs/background-workers

### Generate the session locally

On a trusted computer, install Python 3.13, then:

```bash
python -m pip install -r requirements.txt
python generate_session.py
```

Enter your own API ID/hash, phone/login code and 2FA password if prompted. Copy the resulting **secret** into Render's `SESSION_STRING` variable. Do not use an online session-generator website. The production worker never asks for an interactive login.

### Local development / start command

Install FFmpeg/FFprobe and a supported Node.js runtime separately if not using Docker. Export the three environment variables in your shell (a `.env` file is **not automatically loaded**), then:

```bash
python main.py
# or, on Linux:
sh start.sh
```

## Getting started

```text
.menu                   # first directory page
.menu2                  # second directory page
.menu 3                 # pages 3–12 follow the same pattern
.help music             # exact command syntax and access level
.commands               # downloadable full command reference
.alive
.ping
.music your permitted song name
.tomp3                  # reply to your audio/video
.cp @username           # public profile copy; do not impersonate
.nrml                   # restore your backed-up profile
.purgeme 100             # confirmation required
.purge 9999              # bounded cleanup; confirmation required
.deall 9999              # YOUR messages in THIS chat, not all dialogs
.addbots @yourbot        # max three explicitly named bots
.invitebots @yourbot     # alias of addbots
.rmbots @yourbot         # remove named non-admin bots only
.join @publicgroup
.love                   # 23 steps, one edited message, 3s/frame
.animstop
.stopall                # cancel jobs and clear automatic messaging configuration
```

### Permissions and consent

- Commands come only from your detected owner account or explicitly trusted `.sudo` users. Unknown senders cannot control the account.
- Account changes, sudo grants, forwarding routes, broadcasts, bulk deletion and moderation are **owner-only**. Group actions additionally require Telegram permissions. Some admin actions require a supergroup, and creators may be the only people able to grant particular rights.
- Sudo access is powerful: a trusted user can run non-owner tools through your account. `.sudo` is not a sandbox for untrusted strangers. Use `.delsudo` to revoke it.
- Private recipients must send **`.optin` themselves** before broadcasts/configured replies. They can send **`.optout`** to remove consent, configured replies and routes. Owners cannot subscribe private users for them.
- Use `.bcadd` only in a group you administer and whose members expect broadcasts. `.bcdel` removes a destination.
- `.bc` requires confirmation, runs at most once/hour, and sends to at most 25 opted-in destinations with five-second spacing. `.autobc on 24 | text` schedules future broadcasts; minimum six hours. `.autofw add @destination` requires a permitted source and opted-in destination, max one/minute; no history replay or forwarding chains.
- `.areply` and exact `.filter` responses share a one-minute chat cooldown. AFK notices are separate availability notices, at most once/hour/chat. Bot accounts and command-like incoming text are ignored by auto-replies.
- Deletion is irreversible. Purges stop before the original command, use batches up to 100, and require a 60-second confirmation token tied to the owner and chat. `.purgeme 9999` searches up to 9999 of your messages; `.purge 9999` searches up to 9999 messages. Availability, permissions and history access may reduce what can be deleted.
- `.muteall` changes group defaults rather than looping over every member. `.unmuteall` restores the saved defaults. Existing individual restrictions remain; admins are exempt.
- `.stopall` cancels background jobs and **clears** automatic replies, filters, forwarding routes, broadcast schedules, AFK, autoread and pending reminders. Notes, sudo users and opted-in destinations remain. It cannot undo messages/deletions already completed or a request already accepted by Telegram.

## MP3 behaviour

`.music` uses yt-dlp, FFmpeg and FFprobe. The final file must have an **MP3 audio stream and no video stream** before it is sent with `audio/mpeg` and Telegram audio metadata. This is real conversion, not renaming an MP4 file. `.tomp3` converts replied audio/video in the same way. Input downloads are limited to 50 MB and conversion length to 15 minutes.

Network downloaders remain dependent on source availability and hosting-IP restrictions. YouTube may request sign-in, additional runtime support or block Render IPs. Private/DRM content is not bypassed. No cookies or account passwords are collected by this project. Only download material you own or have permission to use. `.dl` works on replied Telegram media, not arbitrary server URLs. Protected Telegram chat content is not downloaded/resubmitted by `.dl` or media-conversion commands.

## Persistence and recovery

The first state-changing command creates `/var/data/nik/settings.json` with restrictive file permissions. Defaults are initialized in code; no manual JSON templates are necessary. Atomic writes plus an in-process lock protect concurrent updates. Profile backups use the same persistent directory.

`.backup` sends state privately to Saved Messages, excluding credentials. To restore: stop the worker, replace `settings.json` on its persistent disk with your own known-good backup, and restart. Do not restore JSON from strangers—it contains privileged sudo IDs and messaging settings. Corrupt JSON fails closed rather than silently erasing your state.

Reminders persist and are delivered to Saved Messages when the worker is online. A crash between sending and saving could duplicate a reminder (at-least-once delivery, not exactly-once). Active purges, conversions, animations and one-off broadcasts do **not** resume on restart. Automatic broadcast schedules resume without replaying every missed interval.

## Testing: what is and is not verified

See [AUDIT.md](AUDIT.md) and `docs/test-results.txt`.

- 572 automated tests passed in the sandbox; 85% measured statement coverage.
- Ten test modules cover registry, storage, security, text tools, cleaning, moderation, automation, profile/notes, media, menus/animations.
- Real local FFmpeg/FFprobe MP3 conversion and incorrect-codec rejection were tested.
- Telegram operations were tested with mocks, **not a logged-in Telegram account**. External downloads and an actual Render deploy were **not performed**. Docker is configured but was not built in this sandbox.
- Counts include parameterized registry/help tests; 572 tests do **not** mean 572 live integration checks or zero remaining bugs.

Run checks yourself:

```bash
python -m pip install -r requirements-dev.txt
python -m compileall -q nik main.py generate_session.py
ruff check nik tests main.py generate_session.py --select F
python -m pytest -q --cov=nik --cov-report=term-missing
```

Test destructive/admin commands only in a private test group you own before enabling them in a real group. Use `docs/LIVE_CHECKLIST.md` after deployment.
