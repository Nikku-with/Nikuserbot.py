"""Run locally on a trusted computer, never in a shared web console."""

import asyncio
from getpass import getpass
from telethon import TelegramClient
from telethon.sessions import StringSession


async def main():
    api_id = int(input("API_ID: "))
    api_hash = getpass("API_HASH: ")
    async with TelegramClient(StringSession(), api_id, api_hash) as client:
        print("SECRET — full account access. Store only in SESSION_STRING:")
        print(client.session.save())


if __name__ == "__main__":
    asyncio.run(main())
